export type User = {
  id: string;
  name: string;
  email: string;
  role: 'farmer' | 'dealer' | 'admin';
  location: string;
  avatarUrl: string;
  kissanId?: string;
  aadharNumber?: string;
  mobile?: string;
};

export type CropBatch = {
  id: string;
  farmerId: string;
  cropType: string;
  variety: string;
  quantity: number; // in kg
  plantingDate: string; // ISO 8601 date string
  expectedHarvestDate: string; // ISO 8601 date string
  harvestDate: string; // ISO 8601 date string
  farmLocation: string;
  status: 'registered' | 'listed' | 'sold';
  priceInRupees?: number; // per kg
  soldTo?: string; // dealerId
  transactionId?: string;
  // Optional fields not on blockchain
  seedName?: string;
  qualityScore?: number;
  mfgDate?: string;
  landArea?: number;
};

export type Transaction = {
  id: string;
  batchId: string;
  farmerId: string;
  dealerId: string;
  purchaseDate: string;
  quantity: number;
  pricePerKgInRupees: number;
  totalAmountInRupees: number;
};

export type IoTData = {
  temperature: number; // Celsius
  humidity: number; // Percentage
  location: string;
};

export type SupplyChainEvent = {
  id: string;
  batchId: string;
  type: 'HARVEST' | 'STORAGE' | 'TRANSIT' | 'SALE' | 'DELIVERY';
  timestamp: string;
  title: string;
  description: string;
  actor: {
    id: string;
    name: string;
    role: 'FARMER' | 'LOGISTICS' | 'DEALER' | 'RETAILER';
  };
  iotData?: IoTData;
  costInRupees?: number;
};
