
'use client';

import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import React from 'react';

import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Loader2, ShieldCheck } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { useToast } from '@/hooks/use-toast';


const formSchema = z.object({
  cropType: z.string().min(1, 'Crop type is required'),
  variety: z.string().min(1, 'Variety is required'),
  quantity: z.coerce.number().min(1, 'Quantity must be positive'),
  seedName: z.string().min(1, 'Seed name is required'),
  qualityScore: z.coerce.number().min(0).max(100, 'Score must be between 0 and 100'),
  mfgDate: z.string().min(1, 'Manufacturing date is required'),
  plantingDate: z.string().min(1, 'Planting date is required'),
  farmLocation: z.string().min(1, 'Farm location is required'),
  landArea: z.coerce.number().min(0.1, 'Land area must be positive'),
  expectedHarvestDate: z.string().min(1, 'Expected harvest date is required'),
  terms: z.boolean().default(false).refine(val => val === true, { message: 'You must accept the terms' }),
});

type FormValues = z.infer<typeof formSchema>;


export function AddBatchClient() {
  const [error, setError] = React.useState<string | null>(null);
  const [isLoading, setIsLoading] = React.useState(false);
  const router = useRouter();
  const { toast } = useToast();

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      cropType: 'Wheat',
      variety: 'HD-3226',
      seedName: 'Shriram Super 303',
      qualityScore: 95,
      mfgDate: new Date().toISOString().split('T')[0],
      plantingDate: new Date().toISOString().split('T')[0],
      farmLocation: 'Punjab, India',
      landArea: 10,
      expectedHarvestDate: new Date(new Date().setMonth(new Date().getMonth() + 4)).toISOString().split('T')[0],
      terms: true,
      quantity: 5000,
    },
  });

  async function onSubmit(values: FormValues) {
    setIsLoading(true);
    setError(null);
    
    // Blockchain logic will be re-implemented here.
    console.log("Form submitted with values:", values);
    
    toast({
        title: "In Progress",
        description: "Blockchain logic needs to be implemented."
    });

    // Simulate a delay
    await new Promise(resolve => setTimeout(resolve, 1500));

    setIsLoading(false);
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Add New Crop Batch</CardTitle>
        <CardDescription>
          Fill in the details below to register a new crop batch on the Waymark platform and blockchain.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="cropType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Crop Type</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a crop" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="Wheat">Wheat</SelectItem>
                        <SelectItem value="Basmati Rice">Basmati Rice</SelectItem>
                        <SelectItem value="Corn">Corn</SelectItem>
                        <SelectItem value="Soybean">Soybean</SelectItem>
                        <SelectItem value="Cotton">Cotton</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
               <FormField
                control={form.control}
                name="variety"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Variety</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., HD-3226" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="quantity"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Quantity (in kg)</FormLabel>
                    <FormControl>
                      <Input type="number" placeholder="e.g., 5000" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="seedName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Seed Name</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., Shriram Super 303" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="qualityScore"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Quality Score</FormLabel>
                    <FormControl>
                      <Input type="number" placeholder="0-100" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
               <FormField
                control={form.control}
                name="mfgDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Seed Manuf. Date</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="plantingDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Planting Date</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="farmLocation"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Farm Location</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., Punjab, India" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
               <FormField
                control={form.control}
                name="landArea"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Land Area (in acres)</FormLabel>
                    <FormControl>
                      <Input type="number" placeholder="e.g., 10" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="expectedHarvestDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Expected Harvest Date</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
             <FormField
                control={form.control}
                name="terms"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4 shadow">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <Label htmlFor="terms">Acknowledge Ledger Recording</Label>
                      <FormDescription>
                        I understand this batch registration will be permanently and transparently recorded on a secure, decentralized ledger.
                      </FormDescription>
                       <FormMessage />
                    </div>
                  </FormItem>
                )}
              />

            {error && (
              <Alert variant="destructive">
                <AlertTitle>Error</AlertTitle>
                <AlertDescription>{error}</AlertDescription>
              </Aler>
            )}

            <div className="flex justify-end gap-2">
                 <Button variant="outline" type="button" onClick={() => router.back()}>Cancel</Button>
                <Button type="submit" disabled={isLoading}>
                    {isLoading ? (
                    <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Registering...
                    </>
                    ) : (
                    <><ShieldCheck className="mr-2 h-4 w-4" />Register Batch on Blockchain</>
                    )}
                </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
