

import type { User, CropBatch, Transaction, SupplyChainEvent } from './types';
import path from 'path';
import { promises as fs } from 'fs';

const cropBatchesFilePath = path.join(process.cwd(), 'src', 'lib', 'db', 'cropBatches.json');
const transactionsFilePath = path.join(process.cwd(), 'src', 'lib', 'db', 'transactions.json');
const usersFilePath = path.join(process.cwd(), 'src', 'lib', 'db', 'users.json');

export async function getUsers(): Promise<User[]> {
  try {
    const data = await fs.readFile(usersFilePath, 'utf-8');
    return JSON.parse(data);
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === 'ENOENT') {
      return [];
    }
    throw error;
  }
}
export const users: User[] = await getUsers();


// Helper function to get a date string for the past
const getDateInPast = (days: number): string => {
  const date = new Date();
  date.setDate(date.getDate() - days);
  return date.toISOString().split('T')[0];
};

const addTime = (isoDate: string, days: number = 0, hours: number = 0, minutes: number = 0) => {
    const date = new Date(isoDate);
    date.setDate(date.getDate() + days);
    date.setHours(date.getHours() + hours);
    date.setMinutes(date.getMinutes() + minutes);
    return date.toISOString();
}

export async function getTransactions(): Promise<Transaction[]> {
    try {
        const data = await fs.readFile(transactionsFilePath, 'utf-8');
        return JSON.parse(data);
    } catch (error) {
        if ((error as NodeJS.ErrnoException).code === 'ENOENT') {
            return [];
        }
        throw error;
    }
}

export async function saveTransactions(transactions: Transaction[]) {
    await fs.writeFile(transactionsFilePath, JSON.stringify(transactions, null, 2), 'utf-8');
}


const logisticsCompanies = [
    { id: "logistics-1", name: "Safe Cargo" },
    { id: "logistics-2", name: "Speedy Transport" },
    { id: "logistics-3", name: "Agri-Haul" }
];
const retailerNames = ["FreshMart", "GrocerZone", "Nature's Basket", "BigBasket", "Reliance Fresh", "DMart", "HyperCity", "Star Bazaar", "Easyday", "More"];
const retailLocations = ["Mumbai", "Delhi", "Bangalore", "Chennai", "Kolkata", "Hyderabad", "Pune", "Ahmedabad", "Jaipur", "Lucknow"];


export let supplyChainEvents: SupplyChainEvent[] = [];

// Function to build a full supply chain for a given transaction and batch
async function buildChainForBatch(batch: CropBatch, transaction: Transaction, markAsDelivered: boolean) {
    const farmer = users.find(u => u.id === batch.farmerId);
    const dealer = users.find(u => u.id === transaction.dealerId);
    if (!farmer || !dealer) return;

    const logistics = logisticsCompanies[Math.floor(Math.random() * logisticsCompanies.length)];
    
    // Find the original root batch to get the true harvest date
    const allBatches = await getCropBatches();
    let rootBatch = batch;
    while(rootBatch.parentBatchId) {
        const parent = allBatches.find(b => b.id === rootBatch.parentBatchId);
        if(parent) {
            rootBatch = parent;
        } else {
            break;
        }
    }
    
    const baseCost = (Math.floor(Math.random() * 1000) + 4000) * rootBatch.quantity;
    const saleCost = baseCost + (Math.floor(Math.random() * 500) + 500) * rootBatch.quantity;
    const deliveryCost = saleCost + (Math.floor(Math.random() * 500) + 500) * rootBatch.quantity;
    const finalRetailCost = Math.min(9999 * rootBatch.quantity, deliveryCost + (Math.floor(Math.random() * 1000) + 1000) * rootBatch.quantity);


    const harvestTime = addTime(rootBatch.harvestDate, 0, 9); // 9 AM on harvest day
    const storageTime = addTime(harvestTime, 0, 4); // 4 hours after harvest
    const saleTime = addTime(transaction.purchaseDate, 0, 11); // 11 AM on purchase day
    const transitTime = addTime(saleTime, 0, 2); // 2 hours after sale
    const deliveryTime = addTime(transitTime, 1, 6); // 1 day 6 hours after transit start
    
    const baseEvents: SupplyChainEvent[] = [
        { id: `evt-${rootBatch.id}-1-harvest`, batchId: rootBatch.id, type: "HARVEST", timestamp: harvestTime, title: `${rootBatch.cropType} Harvested`, description: `Harvested and prepared for storage.`, actor: { id: farmer.id, name: farmer.name, role: "FARMER" }, iotData: { temperature: 28, humidity: 45, location: rootBatch.farmLocation }, costInRupees: baseCost },
        { id: `evt-${rootBatch.id}-2-storage`, batchId: rootBatch.id, type: "STORAGE", timestamp: storageTime, title: "Stored at Farm", description: `Stored in farm silo #${Math.floor(Math.random() * 10) + 1}.`, actor: { id: farmer.id, name: farmer.name, role: "FARMER" }, iotData: { temperature: 18, humidity: 40, location: `${rootBatch.farmLocation} Silo` } },
        { id: `evt-${rootBatch.id}-3-sale`, batchId: rootBatch.id, type: "SALE", timestamp: saleTime, title: `Sold to ${dealer.name}`, description: `Portion of batch sold to ${dealer.name}.`, actor: { id: farmer.id, name: farmer.name, role: "FARMER" }, costInRupees: saleCost },
        { id: `evt-${rootBatch.id}-4-transit`, batchId: rootBatch.id, type: "TRANSIT", timestamp: transitTime, title: "In Transit to Warehouse", description: `Transported by '${logistics.name}'.`, actor: { id: logistics.id, name: logistics.name, role: "LOGISTICS" }, iotData: { temperature: 20, humidity: 42, location: "On NH 48" } },
    ];

    if(markAsDelivered){
        baseEvents.push({ id: `evt-${batch.id}-5-delivery`, batchId: batch.parentBatchId || batch.id, type: "DELIVERY", timestamp: deliveryTime, title: "Delivered to Retailer Network", description: `Delivered to distribution center in ${dealer.location}.`, actor: { id: dealer.id, name: dealer.name, role: "DEALER" }, costInRupees: deliveryCost });
    }

    supplyChainEvents.push(...baseEvents);

    // Create multiple smaller retail sales from the main batch
    let remainingQuantity = batch.quantity;
    let saleCount = 0;
    const deliveryDate = new Date(deliveryTime);

    // Only create retail sales if the batch was delivered
    if (markAsDelivered) {
        while (remainingQuantity > 0 && saleCount < 20) { // Limit sales to avoid infinite loops
            saleCount++;
            const saleQuantity = Math.min(remainingQuantity, Math.floor(Math.random() * (batch.quantity / 5)) + 10);
            remainingQuantity -= saleQuantity;

            const retailerName = retailerNames[Math.floor(Math.random() * retailerNames.length)];
            const retailLocation = retailLocations[Math.floor(Math.random() * retailLocations.length)];
            const retailSaleTime = new Date(deliveryDate.getTime() + (saleCount * 2 * 60 * 60 * 1000) + (Math.random() * 24 * 60 * 60 * 1000));
            
            const retailSale: SupplyChainEvent = {
                id: `evt-${rootBatch.id}-6-retailsale-${saleCount}`,
                batchId: rootBatch.id,
                type: "SALE",
                timestamp: retailSaleTime.toISOString(),
                title: "Sold to Customer",
                description: `${saleQuantity}kg of ${rootBatch.cropType} sold at ${retailerName}.`,
                actor: { id: `retailer-${Math.floor(Math.random() * 10)}`, name: retailerName, role: "RETAILER" },
                iotData: { temperature: 22, humidity: 55, location: `${retailLocation} Retail` },
                costInRupees: finalRetailCost * (saleQuantity / rootBatch.quantity),
                quantity: saleQuantity,
            };
            supplyChainEvents.push(retailSale);
        }
    }
}


// Build the chain for all transactions
export async function buildAllChains() {
    const cropBatches = await getCropBatches();
    const allTransactions = await getTransactions();
    
    supplyChainEvents = []; // Clear previous events
    let deliveredCount = 0;
    
    for (const tx of allTransactions) {
        const batch = cropBatches.find(b => b.id === tx.batchId);
        if (batch) {
             // Mark most as delivered, but keep some as active holdings
            const markAsDelivered = deliveredCount < 17;
            await buildChainForBatch(batch, tx, markAsDelivered);
            if(markAsDelivered) {
                deliveredCount++;
            }
        }
    }
    
    supplyChainEvents.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
};

buildAllChains();



export const getFarmerById = (id: string) => users.find(u => u.id === id && u.role === 'farmer');
export const getDealerById = (id: string) => users.find(u => u.id === id && u.role === 'dealer');
export const getEventById = (eventId: string): SupplyChainEvent | undefined => supplyChainEvents.find(e => e.id === eventId);

export async function getCropBatches(): Promise<CropBatch[]> {
  try {
    const data = await fs.readFile(cropBatchesFilePath, 'utf-8');
    return JSON.parse(data);
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === 'ENOENT') {
      return [];
    }
    throw error;
  }
}

function createSimulatedTimeline(rootBatch: CropBatch, farmer: User, dealer: User, status: CropBatch['status']): SupplyChainEvent[] {
    const events: SupplyChainEvent[] = [];
    
    const baseCost = (Math.floor(Math.random() * 1000) + 4000) * (rootBatch.originalQuantity || rootBatch.quantity);
    const saleCost = baseCost + (Math.floor(Math.random() * 500) + 500) * (rootBatch.originalQuantity || rootBatch.quantity);
    const deliveryCost = saleCost + (Math.floor(Math.random() * 500) + 500) * (rootBatch.originalQuantity || rootBatch.quantity);
    const retailCost = Math.min(9999 * (rootBatch.originalQuantity || rootBatch.quantity), deliveryCost + (Math.floor(Math.random() * 1000) + 1000) * (rootBatch.originalQuantity || rootBatch.quantity));

    const logistics = logisticsCompanies[Math.floor(Math.random() * logisticsCompanies.length)];
    
    const harvestTime = addTime(rootBatch.harvestDate, 0, 9);
    const storageTime = addTime(harvestTime, 0, 4);

    // Stage 1 & 2: Always present for any status
    events.push(
        { id: `sim-${rootBatch.id}-1`, batchId: rootBatch.id, type: "HARVEST", timestamp: harvestTime, title: `${rootBatch.cropType} Harvested`, description: `Harvested and prepared for storage.`, actor: { id: farmer.id, name: farmer.name, role: "FARMER" }, costInRupees: baseCost, iotData: { temperature: 28, humidity: 45, location: rootBatch.farmLocation } },
        { id: `sim-${rootBatch.id}-2`, batchId: rootBatch.id, type: "STORAGE", timestamp: storageTime, title: "Stored at Farm", description: `Stored in farm silo.`, actor: { id: farmer.id, name: farmer.name, role: "FARMER" }, iotData: { temperature: 18, humidity: 40, location: `${rootBatch.farmLocation} Silo` } }
    );
    
    if (status === 'registered' || status === 'listed') {
        return events.sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
    }
    
    // If the batch is 'sold', add all subsequent events
    const saleTime = addTime(harvestTime, 1, 11);
    const transitTime = addTime(saleTime, 0, 2);
    const deliveryTime = addTime(transitTime, 1, 6);
    const retailSaleTime = addTime(deliveryTime, 0, 8);
    const retailerName = retailerNames[Math.floor(Math.random() * retailerNames.length)];
    const retailLocation = retailLocations[Math.floor(Math.random() * retailLocations.length)];
    
    events.push(
        { id: `sim-${rootBatch.id}-3`, batchId: rootBatch.id, type: "SALE", timestamp: saleTime, title: `Sold to ${dealer.name}`, description: `Batch sold to ${dealer.name}.`, actor: { id: farmer.id, name: farmer.name, role: "FARMER" }, costInRupees: saleCost },
        { id: `sim-${rootBatch.id}-4`, batchId: rootBatch.id, type: "TRANSIT", timestamp: transitTime, title: "In Transit to Warehouse", description: `Transported by '${logistics.name}'.`, actor: { id: logistics.id, name: logistics.name, role: "LOGISTICS" }, iotData: { temperature: 20, humidity: 42, location: "On NH 48" } },
        { id: `sim-${rootBatch.id}-5`, batchId: rootBatch.id, type: "DELIVERY", timestamp: deliveryTime, title: "Delivered to Retailer Network", description: `Delivered to distribution center in ${dealer.location}.`, actor: { id: dealer.id, name: dealer.name, role: "DEALER" }, costInRupees: deliveryCost },
        { id: `sim-${rootBatch.id}-6`, batchId: rootBatch.id, type: "SALE", timestamp: retailSaleTime, title: "Sold to Customer", description: `${rootBatch.quantity}kg of ${rootBatch.cropType} sold at ${retailerName}.`, actor: { id: `retailer-sim`, name: retailerName, role: "RETAILER" }, iotData: { temperature: 22, humidity: 55, location: `${retailLocation} Retail` }, costInRupees: retailCost, quantity: rootBatch.quantity }
    );
    
    return events.sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
}

export async function getEventsForBatch(batchId: string): Promise<SupplyChainEvent[]> {
  const allBatches = await getCropBatches();
  
  const targetBatch = allBatches.find(b => b.id === batchId);
  if (!targetBatch) {
    return [];
  }
  
  if (targetBatch.status === 'registered' || targetBatch.status === 'listed') {
      const rootBatch = allBatches.find(b => b.id === (targetBatch.parentBatchId || targetBatch.id)) || targetBatch;
      const farmer = getFarmerById(rootBatch.farmerId);
      const simulatedDealer = getDealerById('dealer-1') || users.find(u => u.role === 'dealer');
      if (farmer && simulatedDealer) {
          return createSimulatedTimeline(rootBatch, farmer, simulatedDealer, targetBatch.status);
      }
      return [];
  }

  // Find the ultimate root parent of the batch
  let rootBatch = targetBatch;
  while (rootBatch.parentBatchId) {
    const parent = allBatches.find(b => b.id === rootBatch.parentBatchId);
    if (parent) {
      rootBatch = parent;
    } else {
      break; 
    }
  }
  const rootBatchId = rootBatch.id;

  const farmer = getFarmerById(rootBatch.farmerId);
  const simulatedDealer = getDealerById('dealer-1') || users.find(u => u.role === 'dealer');

  // Find all events associated with the root batch.
  let events = supplyChainEvents.filter(e => e.batchId === rootBatchId);

  // If no "real" events are found (e.g., for newly created 'sold' batches), generate a simulated timeline.
  if (events.length === 0 && farmer && simulatedDealer) {
      events = createSimulatedTimeline(rootBatch, farmer, simulatedDealer, targetBatch.status);
  } else {
    // Also, find events that are specific to the sub-batch (like a specific DELIVERY event)
    const subBatchEvents = supplyChainEvents.filter(e => e.batchId === batchId && e.batchId !== rootBatchId);
    events.push(...subBatchEvents);
  }

  // Remove duplicates and sort
  events = [...new Map(events.map(e => [e.id, e])).values()]
    .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
  
  return events;
}

export async function saveCropBatches(cropBatches: CropBatch[]) {
  await fs.writeFile(cropBatchesFilePath, JSON.stringify(cropBatches, null, 2), 'utf-8');
}
