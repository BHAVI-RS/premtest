
'use client';

import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import React from 'react';

import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Loader2, User as UserIcon } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { getCurrentUser, updateUserDetails, type UserUpdateData } from './actions';
import type { User } from '@/lib/types';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { usePathname } from 'next/navigation';

const formSchema = z.object({
  name: z.string().min(1, 'Name is required'),
  email: z.string().email('Invalid email address').optional().or(z.literal('')),
  location: z.string().min(1, 'Location is required'),
  avatarUrl: z.string().url('Please enter a valid URL.').optional().or(z.literal('')),
});

type FormValues = z.infer<typeof formSchema>;

export function SettingsClient() {
  const [error, setError] = React.useState<string | null>(null);
  const [isLoading, setIsLoading] = React.useState(false);
  const [user, setUser] = React.useState<User | null>(null);
  const { toast } = useToast();
  const pathname = usePathname();

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: '',
      email: '',
      location: '',
      avatarUrl: '',
    },
  });

  React.useEffect(() => {
    async function fetchUser() {
      setIsLoading(true);
      // In a real app, you'd get the current user's ID from the session
      const currentUserId = pathname.includes('/dealer/') ? 'dealer-1' : 'farmer-1';
      const fetchedUser = await getCurrentUser(currentUserId);
      if (fetchedUser) {
        setUser(fetchedUser);
        form.reset({
          name: fetchedUser.name,
          email: fetchedUser.email,
          location: fetchedUser.location,
          avatarUrl: fetchedUser.avatarUrl,
        });
      } else {
        setError('Could not load user data.');
      }
      setIsLoading(false);
    }
    fetchUser();
  }, [form, pathname]);

  async function onSubmit(values: FormValues) {
    if (!user) return;
    setIsLoading(true);
    setError(null);

    const result = await updateUserDetails(user.id, values);

    if (result.success && result.user) {
      setUser(result.user);
       form.reset({
          name: result.user.name,
          email: result.user.email,
          location: result.user.location,
          avatarUrl: result.user.avatarUrl,
        });
      toast({
        title: 'Profile Updated',
        description: 'Your information has been successfully saved.',
      });
    } else {
      setError(result.error ?? 'An unknown error occurred.');
    }
    setIsLoading(false);
  }

  const handleAvatarUpload = () => {
    const newUrl = window.prompt("Enter the URL for your new profile picture:", form.getValues("avatarUrl") || "");
    if (newUrl) {
      form.setValue("avatarUrl", newUrl, { shouldValidate: true });
    }
  };


  if (!user && isLoading) {
    return (
      <Card>
        <CardContent className="p-6 flex justify-center items-center">
          <Loader2 className="mr-2 h-8 w-8 animate-spin" />
          <p>Loading your profile...</p>
        </CardContent>
      </Card>
    );
  }

  if (!user) {
    return (
         <Card>
            <CardHeader>
                <CardTitle className="text-destructive">Error</CardTitle>
                <CardDescription>Could not load user profile. Please try again later.</CardDescription>
            </CardHeader>
        </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Edit Profile</CardTitle>
        <CardDescription>
          Update your account details. Click save when you're done.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
             <FormField
              control={form.control}
              name="avatarUrl"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Profile Picture</FormLabel>
                  <FormControl>
                    <div className="flex items-center gap-4">
                        <Avatar className="h-20 w-20">
                            <AvatarImage src={field.value ?? undefined} />
                            <AvatarFallback>
                                <UserIcon className="h-10 w-10" />
                            </AvatarFallback>
                        </Avatar>
                        <Button type="button" variant="outline" onClick={handleAvatarUpload}>
                            Upload Picture
                        </Button>
                    </div>
                  </FormControl>
                  <FormDescription>
                    Enter a URL for your profile picture.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Full Name</FormLabel>
                  <FormControl>
                    <Input placeholder="Your full name" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Email Address</FormLabel>
                  <FormControl>
                    <Input type="email" placeholder="your.email@example.com" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
             <FormField
              control={form.control}
              name="location"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Location</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g., Punjab, India" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {error && (
              <Alert variant="destructive">
                <AlertTitle>Error</AlertTitle>
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <div className="flex justify-end">
              <Button type="submit" disabled={isLoading}>
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Saving...
                  </>
                ) : (
                  'Save Changes'
                )}
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
