
import { Suspense } from 'react';
import { SettingsClient } from './client';
import { Card, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

export default function SettingsPage() {
  return (
    <div>
        <Card className="mb-6">
        <CardHeader>
            <CardTitle>Profile Settings</CardTitle>
            <CardDescription>
                Manage your personal information and application settings.
            </CardDescription>
        </CardHeader>
        </Card>
        <Suspense fallback={<div>Loading...</div>}>
            <SettingsClient />
        </Suspense>
    </div>
  );
}
