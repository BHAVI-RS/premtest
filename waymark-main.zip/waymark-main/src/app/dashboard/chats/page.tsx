
'use client';

import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Search, Send, Phone, Video } from 'lucide-react';
import React from 'react';

const conversations = [
  {
    id: 1,
    name: 'Agro Deals Inc.',
    avatar: '/placeholder-dealer.png',
    messages: [
      { sender: 'other', text: 'Hi Rajesh, we saw your new Wheat batch (HD-3226). We are interested in purchasing the full 5000kg.', timestamp: '10:30 AM' },
      { sender: 'me', text: 'Hello! Glad to hear it. I can offer it at ₹24/kg based on the quality score.', timestamp: '10:31 AM' },
      { sender: 'other', text: 'That sounds fair. Can you arrange for transport to our Mumbai warehouse?', timestamp: '10:32 AM' },
      { sender: 'me', text: 'Absolutely. I can have it dispatched by tomorrow morning. I will share the logistics details shortly.', timestamp: '10:33 AM' },
      { sender: 'other', text: 'Perfect. Please raise the invoice on the platform, and we will process the payment right away.', timestamp: '10:34 AM' },
    ],
    lastMessage: 'Perfect. Please raise the invoice...',
    lastMessageTime: '10:34 AM',
    unread: 0,
  },
  {
    id: 2,
    name: 'Sunita Devi',
    avatar: '/placeholder-farmer-female.png',
    messages: [
      { sender: 'other', text: 'Rajesh ji, thank you for the advice on the new pesticide. It worked wonders for my cotton crop!', timestamp: 'Yesterday' },
      { sender: 'me', text: 'You are most welcome, Sunita ji. Happy to help a fellow farmer!', timestamp: 'Yesterday' },
    ],
    lastMessage: 'You are most welcome, Sunita ji...',
    lastMessageTime: 'Yesterday',
    unread: 0,
  },
   {
    id: 3,
    name: 'GreenHarvest Trading',
    avatar: '/placeholder-dealer-2.png',
    messages: [
      { sender: 'other', text: 'Payment for batch #0x4d5e6... has been completed. Thank you for the quick delivery.', timestamp: 'Tuesday' },
      { sender: 'me', text: 'Thank you for the prompt payment!', timestamp: 'Tuesday' },
    ],
    lastMessage: 'Thank you for the prompt payment!',
    lastMessageTime: 'Tuesday',
    unread: 0,
  },
  {
    id: 4,
    name: 'Amit Singh',
    avatar: '/placeholder-farmer-male.png',
    messages: [
        { sender: 'other', text: 'Is the government MSP for wheat applicable on WayMark?', timestamp: 'Monday'},
        { sender: 'me', text: 'You can always list at MSP, but the AI predictor often suggests a better price based on quality. Worth checking it out.', timestamp: 'Monday'}
    ],
    lastMessage: 'You can always list at MSP...',
    lastMessageTime: 'Monday',
    unread: 1,
  },
   {
    id: 5,
    name: 'Logistics Team',
    avatar: '/placeholder-logistics.png',
    messages: [
        { sender: 'other', text: 'Complaint #234: Your last delivery was delayed by 3 hours. Please ensure drivers adhere to schedule.', timestamp: 'Last Week'},
    ],
    lastMessage: 'Complaint #234: Your last delivery...',
    lastMessageTime: 'Last Week',
    unread: 0,
  }
];

export default function ChatsPage() {
  const [selectedChat, setSelectedChat] = React.useState(conversations[0]);

  return (
     <Card className="h-[calc(100vh-8rem)]">
        <div className="grid grid-cols-1 md:grid-cols-3 h-full">
            {/* Conversations List */}
            <div className="col-span-1 border-r flex flex-col">
                <CardHeader>
                    <CardTitle>Chats</CardTitle>
                    <CardDescription>Your recent conversations.</CardDescription>
                     <div className="relative mt-2">
                        <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                        <Input placeholder="Search messages..." className="w-full rounded-lg bg-background pl-8" />
                    </div>
                </CardHeader>
                <ScrollArea className="flex-grow">
                   <div className="flex flex-col gap-1 p-2">
                        {conversations.map((convo) => (
                        <button
                            key={convo.id}
                            onClick={() => setSelectedChat(convo)}
                            className={`flex items-start gap-4 p-3 rounded-lg text-left transition-colors w-full ${selectedChat.id === convo.id ? 'bg-muted' : 'hover:bg-muted/50'}`}
                        >
                            <Avatar className="h-10 w-10 border">
                                <AvatarFallback>{convo.name.charAt(0)}</AvatarFallback>
                            </Avatar>
                            <div className="flex-grow truncate">
                                <div className="flex justify-between items-center">
                                    <p className="font-semibold">{convo.name}</p>
                                    <p className="text-xs text-muted-foreground">{convo.lastMessageTime}</p>
                                </div>
                                <p className={`text-sm truncate ${convo.unread > 0 ? 'text-foreground font-medium' : 'text-muted-foreground'}`}>
                                    {convo.lastMessage}
                                </p>
                            </div>
                              {convo.unread > 0 && (
                                <div className="flex items-center justify-center h-full">
                                    <span className="flex h-5 w-5 items-center justify-center rounded-full bg-primary text-xs text-primary-foreground">
                                        {convo.unread}
                                    </span>
                                </div>
                            )}
                        </button>
                        ))}
                   </div>
                </ScrollArea>
            </div>

            {/* Main Chat Window */}
            <div className="col-span-2 flex flex-col h-full">
               {selectedChat ? (
                <>
                <div className="flex items-center p-3 border-b">
                     <Avatar className="h-10 w-10 border">
                        <AvatarFallback>{selectedChat.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div className="ml-4 flex-grow">
                        <p className="font-semibold">{selectedChat.name}</p>
                        <p className="text-xs text-green-500">Online</p>
                    </div>
                    <div className="flex items-center gap-2">
                        <Button variant="ghost" size="icon"><Phone /></Button>
                        <Button variant="ghost" size="icon"><Video /></Button>
                    </div>
                </div>
                
                <ScrollArea className="flex-grow p-4 bg-muted/20">
                    <div className="flex flex-col gap-4">
                        {selectedChat.messages.map((msg, index) => (
                             <div key={index} className={`flex items-end gap-2 ${msg.sender === 'me' ? 'justify-end' : 'justify-start'}`}>
                                {msg.sender === 'other' && <Avatar className="h-8 w-8"><AvatarFallback>{selectedChat.name.charAt(0)}</AvatarFallback></Avatar>}
                                 <div className={`max-w-xs md:max-w-md lg:max-w-lg rounded-xl p-3 ${msg.sender === 'me' ? 'bg-primary text-primary-foreground' : 'bg-background border'}`}>
                                    <p className="text-sm">{msg.text}</p>
                                    <p className={`text-xs mt-1 ${msg.sender === 'me' ? 'text-primary-foreground/70' : 'text-muted-foreground'}`}>{msg.timestamp}</p>
                                </div>
                             </div>
                        ))}
                    </div>
                </ScrollArea>

                <div className="p-4 border-t bg-background">
                    <div className="relative">
                        <Input placeholder="Type your message..." className="pr-12"/>
                        <Button variant="ghost" size="icon" className="absolute right-1 top-1/2 -translate-y-1/2 h-8 w-8">
                            <Send className="h-5 w-5" />
                        </Button>
                    </div>
                </div>
                </>
               ) : (
                <div className="flex flex-col items-center justify-center h-full text-muted-foreground">
                    <p>Select a conversation to start chatting.</p>
                </div>
               )}
            </div>
        </div>
    </Card>
  );
}
