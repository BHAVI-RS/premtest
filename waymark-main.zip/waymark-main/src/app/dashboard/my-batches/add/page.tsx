import { AddBatchClient } from './client';

export default function AddBatchPage() {
  return (
    <div>
      <AddBatchClient />
    </div>
  );
}
