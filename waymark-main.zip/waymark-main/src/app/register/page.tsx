

'use client';

import Link from 'next/link';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { useRouter, useSearchParams } from 'next/navigation';
import React, { Suspense } from 'react';

import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { WaymarkIcon } from '@/components/icons';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { useToast } from '@/hooks/use-toast';
import { ChevronsUpDown, Loader2, Check } from 'lucide-react';
import { registerUser } from './actions';
import type { User } from '@/lib/types';
import { countries } from '@/lib/countries';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from '@/components/ui/command';
import { cn } from '@/lib/utils';


const baseMobileSchema = z.object({
  name: z.string().min(1, 'Full name is required'),
  countryCode: z.string().min(1, "Country code is required"),
  mobile: z.string().refine(val => /^\d+$/.test(val), {
      message: "Mobile number must contain only digits.",
  }),
  email: z.string().email('Invalid email address').optional().or(z.literal('')),
  location: z.string().min(1, 'Location is required'),
  terms: z.boolean().default(false).refine((val) => val === true, {
    message: 'You must accept the terms to register.',
  }),
});

const farmerSchema = baseMobileSchema.extend({
  aadhar: z.string().refine((val) => /^\d{12}$/.test(val.replace(/\s/g, '')), {
    message: 'A valid 12-digit Aadhar number is required',
  }),
  kissanId: z.string().optional(),
}).superRefine((data, ctx) => {
  if (data.countryCode === '91') {
    if (data.mobile.length !== 10) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: 'Mobile number must be 10 digits for India.',
        path: ['mobile'],
      });
    }
    if (!/^[6-9]/.test(data.mobile)) {
        ctx.addIssue({
            code: z.ZodIssueCode.custom,
            message: 'Mobile number must start with 6, 7, 8, or 9.',
            path: ['mobile'],
        });
    }
  } else {
    if (data.mobile.length < 5 || data.mobile.length > 15) {
        ctx.addIssue({
            code: z.ZodIssueCode.custom,
            message: 'Mobile number must be between 5 and 15 digits.',
            path: ['mobile'],
        });
    }
  }
});


const dealerSchema = baseMobileSchema.extend({
   name: z.string().min(1, 'Full name or company name is required'),
   email: z.string().email('Invalid email address'),
   aadhar: z.string().optional().refine((val) => !val || /^\d{12}$/.test(val.replace(/\s/g, '')), {
    message: 'Aadhar must be a 12-digit number if provided',
  }),
}).superRefine((data, ctx) => {
  if (data.countryCode === '91') {
    if (data.mobile.length !== 10) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: 'Mobile number must be 10 digits for India.',
        path: ['mobile'],
      });
    }
    if (!/^[6-9]/.test(data.mobile)) {
        ctx.addIssue({
            code: z.ZodIssueCode.custom,
            message: 'For India, mobile must start with 6, 7, 8, or 9.',
            path: ['mobile'],
        });
    }
  } else {
    if (data.mobile.length < 5 || data.mobile.length > 15) {
        ctx.addIssue({
            code: z.ZodIssueCode.custom,
            message: 'Mobile number must be between 5 and 15 digits.',
            path: ['mobile'],
        });
    }
  }
});

type FarmerFormValues = z.infer<typeof farmerSchema>;
type DealerFormValues = z.infer<typeof dealerSchema>;
type RegistrationData = Omit<User, 'id'>;

function RegisterForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const role = searchParams.get('role');
  const { toast } = useToast();
  const [isLoading, setIsLoading] = React.useState(false);
  const [error, setError] = React.useState('');
  const [farmerPopoverOpen, setFarmerPopoverOpen] = React.useState(false);
  const [dealerPopoverOpen, setDealerPopoverOpen] = React.useState(false);
  const [activeTab, setActiveTab] = React.useState(role === 'dealer' ? 'dealer' : 'farmer');
  
  const [showOtpInput, setShowOtpInput] = React.useState(false);
  const [otp, setOtp] = React.useState('');
  const [otpError, setOtpError] = React.useState('');
  const [pendingRegistrationData, setPendingRegistrationData] = React.useState<RegistrationData | null>(null);

  const farmerForm = useForm<FarmerFormValues>({
    resolver: zodResolver(farmerSchema),
    defaultValues: {
      name: '',
      countryCode: '91',
      mobile: '',
      aadhar: '',
      email: '',
      kissanId: '',
      location: '',
      terms: false,
    },
  });

  const dealerForm = useForm<DealerFormValues>({
    resolver: zodResolver(dealerSchema),
    defaultValues: {
      name: '',
      countryCode: '91',
      mobile: '',
      email: '',
      location: '',
      aadhar: '',
      terms: false,
    },
  });

  const handleRegistrationRequest = async (data: RegistrationData) => {
    setIsLoading(true);
    setError('');

    // Simulate sending OTP
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    setPendingRegistrationData(data);
    setIsLoading(false);
    setShowOtpInput(true);
    toast({ title: 'OTP Sent (Simulated)', description: `An OTP has been sent to ${data.mobile}. Enter 123456 to verify.` });
  };

  const handleVerifyOtpAndRegister = async () => {
    if (otp !== '123456') {
      setOtpError('Invalid OTP. Please try again.');
      return;
    }
    if (!pendingRegistrationData) {
      setError('An unexpected error occurred. Please try again from the beginning.');
      setShowOtpInput(false);
      return;
    }

    setIsLoading(true);
    setError('');
    setOtpError('');

    try {
        const dbResult = await registerUser(pendingRegistrationData);
        if (dbResult.success) {
            toast({ title: 'Registration Complete!', description: 'You have been successfully registered.' });
            if (pendingRegistrationData.role === 'dealer') {
              router.push('/dealer/dashboard');
            } else {
              router.push('/dashboard');
            }
        } else {
            setError(dbResult.error || 'Failed to save user data.');
            toast({ title: 'Registration Error', description: dbResult.error, variant: 'destructive' });
            setShowOtpInput(false); // Go back to form on error
        }
    } catch (e: any) {
        console.error('An error occurred during registration:', e);
        const errorMessage = e.message || 'An unexpected error occurred.';
        setError(errorMessage);
        toast({ title: 'Registration Failed', description: errorMessage, variant: 'destructive' });
        setShowOtpInput(false); // Go back to form on error
    } finally {
        setIsLoading(false);
    }
  };


  const onFarmerSubmit = (values: FarmerFormValues) => {
    const newUser: Omit<User, 'id'> = {
      name: values.name,
      email: values.email || '',
      mobile: `+${values.countryCode}${values.mobile}`,
      role: 'farmer',
      location: values.location,
      kissanId: values.kissanId,
      aadharNumber: values.aadhar.replace(/\s/g, ''),
    };
    handleRegistrationRequest(newUser);
  };

  const onDealerSubmit = (values: DealerFormValues) => {
    const newUser: Omit<User, 'id' | 'kissanId'> = {
      name: values.name,
      email: values.email,
      mobile: `+${values.countryCode}${values.mobile}`,
      role: 'dealer',
      location: values.location,
      aadharNumber: values.aadhar?.replace(/\s/g, ''),
    };
    handleRegistrationRequest(newUser);
  };

  const formatAadhar = (value: string) => {
    const numericValue = value.replace(/\D/g, '');
    const truncatedValue = numericValue.slice(0, 12);
    const parts = [];
    for (let i = 0; i < truncatedValue.length; i += 4) {
      parts.push(truncatedValue.slice(i, i + 4));
    }
    return parts.join(' ');
  };
  
  const OtpVerificationForm = () => (
    <Card>
      <CardHeader>
        <CardTitle>Verify Your Mobile Number</CardTitle>
        <CardDescription>
          Enter the 6-digit code sent to {pendingRegistrationData?.mobile}.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label htmlFor="otp">One-Time Password</Label>
          <Input
            id="otp"
            type="tel"
            maxLength={6}
            value={otp}
            onChange={(e) => setOtp(e.target.value.replace(/\D/g, ''))}
            disabled={isLoading}
            className="mt-1"
          />
        </div>
        {otpError && <p className="text-sm font-medium text-destructive">{otpError}</p>}
        {error && <p className="text-sm font-medium text-destructive">{error}</p>}
        <Button onClick={handleVerifyOtpAndRegister} className="w-full" disabled={isLoading}>
          {isLoading ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Verifying...</> : 'Verify & Register'}
        </Button>
        <Button variant="link" className="w-full" onClick={() => { setShowOtpInput(false); setOtp(''); setOtpError(''); setError(''); setPendingRegistrationData(null); }}>
          Back to registration form
        </Button>
      </CardContent>
    </Card>
  );


  return (
    <div className="flex min-h-screen w-full items-center justify-center bg-muted/40 py-12">
      {showOtpInput ? <OtpVerificationForm /> : (
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full max-w-md mx-4">
          <div className="text-center mb-4">
            <Link href="/" className="flex items-center gap-2 justify-center mb-4" prefetch={false}>
              <WaymarkIcon className="h-8 w-8 text-primary" />
              <span className="text-2xl font-bold tracking-tight text-foreground">WayMark</span>
            </Link>
            <h1 className="text-3xl font-bold">Create an Account</h1>
            <p className="text-balance text-muted-foreground">
              Choose your role and start your journey with us.
            </p>
          </div>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="farmer">Farmer</TabsTrigger>
            <TabsTrigger value="dealer">Dealer</TabsTrigger>
          </TabsList>
          <TabsContent value="farmer">
            <Card>
              <CardHeader>
                <CardTitle>Farmer Registration</CardTitle>
                <CardDescription>
                  Join our network to claim fair price for your produce.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...farmerForm}>
                  <form
                    onSubmit={farmerForm.handleSubmit(onFarmerSubmit)}
                    className="space-y-4"
                  >
                    <FormField
                      control={farmerForm.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Full Name</FormLabel>
                          <FormControl>
                            <Input {...field} disabled={isLoading} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormItem>
                        <FormLabel>Mobile Number</FormLabel>
                        <div className="flex gap-2">
                          <FormField
                              control={farmerForm.control}
                              name="countryCode"
                              render={({ field }) => (
                              <FormItem className="flex flex-col">
                                  <Popover open={farmerPopoverOpen} onOpenChange={setFarmerPopoverOpen}>
                                  <PopoverTrigger asChild>
                                      <FormControl>
                                      <Button
                                          variant="outline"
                                          role="combobox"
                                          className={cn(
                                          "w-[150px] justify-between",
                                          !field.value && "text-muted-foreground"
                                          )}
                                      >
                                          {field.value
                                          ? `+${countries.find(
                                              (country) => country.dial_code === field.value
                                          )?.dial_code}`
                                          : "Select code"}
                                          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                                      </Button>
                                      </FormControl>
                                  </PopoverTrigger>
                                  <PopoverContent className="w-[250px] p-0">
                                      <Command>
                                      <CommandInput placeholder="Search country..." />
                                      <CommandList>
                                          <CommandEmpty>No country found.</CommandEmpty>
                                          <CommandGroup>
                                          <ScrollArea className="h-72">
                                          {countries.map((country) => (
                                              <CommandItem
                                              value={`${country.name} (+${country.dial_code})`}
                                              key={country.code}
                                              onSelect={() => {
                                                  farmerForm.setValue("countryCode", country.dial_code)
                                                  setFarmerPopoverOpen(false)
                                              }}
                                              >
                                              <Check
                                                  className={cn(
                                                  "mr-2 h-4 w-4",
                                                  country.dial_code === field.value
                                                      ? "opacity-100"
                                                      : "opacity-0"
                                                  )}
                                              />
                                              {country.name} (+{country.dial_code})
                                              </CommandItem>
                                          ))}
                                          </ScrollArea>
                                          </CommandGroup>
                                      </CommandList>
                                      </Command>
                                  </PopoverContent>
                                  </Popover>
                                  <FormMessage />
                              </FormItem>
                              )}
                          />
                          <FormField
                              control={farmerForm.control}
                              name="mobile"
                              render={({ field }) => (
                                  <FormItem className="flex-1">
                                      <FormControl>
                                      <Input
                                          type="tel"
                                          {...field}
                                          onChange={(e) => {
                                            const limit = farmerForm.getValues("countryCode") === '91' ? 10 : 15;
                                            field.onChange(e.target.value.replace(/\D/g, '').slice(0, limit));
                                          }}
                                          disabled={isLoading}
                                      />
                                      </FormControl>
                                      <FormMessage />
                                  </FormItem>
                              )}
                          />
                        </div>
                      </FormItem>

                    <FormField
                      control={farmerForm.control}
                      name="aadhar"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Aadhar Number</FormLabel>
                          <FormControl>
                            <Input
                              {...field}
                              onChange={(e) => field.onChange(formatAadhar(e.target.value))}
                              disabled={isLoading}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={farmerForm.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email (Optional)</FormLabel>
                          <FormControl>
                            <Input type="email" {...field} disabled={isLoading} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={farmerForm.control}
                      name="kissanId"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Kissan ID (Optional)</FormLabel>
                          <FormControl>
                            <Input {...field} disabled={isLoading} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={farmerForm.control}
                      name="location"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Location</FormLabel>
                          <FormControl>
                            <Input {...field} disabled={isLoading} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={farmerForm.control}
                      name="terms"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4 shadow">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                              disabled={isLoading}
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <Label>Accept Terms & Conditions</Label>
                            <FormDescription>
                              You agree to our terms of service and privacy policy.
                            </FormDescription>
                            <FormMessage />
                          </div>
                        </FormItem>
                      )}
                    />
                    {error && <p className="text-sm font-medium text-destructive">{error}</p>}
                    <Button type="submit" className="w-full" disabled={isLoading}>
                      {isLoading ? (<><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Sending OTP...</>) : 'Register'}
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="dealer">
            <Card>
              <CardHeader>
                <CardTitle>Dealer Registration</CardTitle>
                <CardDescription>
                  Get access to fresh produce directly from the source.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...dealerForm}>
                  <form
                    onSubmit={dealerForm.handleSubmit(onDealerSubmit)}
                    className="space-y-4"
                  >
                    <FormField
                      control={dealerForm.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Full Name / Company Name</FormLabel>
                          <FormControl>
                            <Input {...field} disabled={isLoading} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormItem>
                        <FormLabel>Mobile Number</FormLabel>
                        <div className="flex gap-2">
                          <FormField
                              control={dealerForm.control}
                              name="countryCode"
                              render={({ field }) => (
                              <FormItem className="flex flex-col">
                                  <Popover open={dealerPopoverOpen} onOpenChange={setDealerPopoverOpen}>
                                  <PopoverTrigger asChild>
                                      <FormControl>
                                      <Button
                                          variant="outline"
                                          role="combobox"
                                          className={cn(
                                          "w-[150px] justify-between",
                                          !field.value && "text-muted-foreground"
                                          )}
                                      >
                                          {field.value
                                          ? `+${countries.find(
                                              (country) => country.dial_code === field.value
                                          )?.dial_code}`
                                          : "Select code"}
                                          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                                      </Button>
                                      </FormControl>
                                  </PopoverTrigger>
                                  <PopoverContent className="w-[250px] p-0">
                                      <Command>
                                      <CommandInput placeholder="Search country..." />
                                      <CommandList>
                                          <CommandEmpty>No country found.</CommandEmpty>
                                          <CommandGroup>
                                          <ScrollArea className="h-72">
                                          {countries.map((country) => (
                                              <CommandItem
                                              value={`${country.name} (+${country.dial_code})`}
                                              key={country.code}
                                              onSelect={() => {
                                                  dealerForm.setValue("countryCode", country.dial_code)
                                                  setDealerPopoverOpen(false)
                                              }}
                                              >
                                              <Check
                                                  className={cn(
                                                  "mr-2 h-4 w-4",
                                                  country.dial_code === field.value
                                                      ? "opacity-100"
                                                      : "opacity-0"
                                                  )}
                                              />
                                              {country.name} (+{country.dial_code})
                                              </CommandItem>
                                          ))}
                                          </ScrollArea>
                                          </CommandGroup>
                                      </CommandList>
                                      </Command>
                                  </PopoverContent>
                                  </Popover>
                                  <FormMessage />
                              </FormItem>
                              )}
                          />
                          <FormField
                              control={dealerForm.control}
                              name="mobile"
                              render={({ field }) => (
                                  <FormItem className="flex-1">
                                      <FormControl>
                                      <Input
                                          type="tel"
                                          {...field}
                                          onChange={(e) => {
                                            const limit = dealerForm.getValues("countryCode") === '91' ? 10 : 15;
                                            field.onChange(e.target.value.replace(/\D/g, '').slice(0, limit));
                                          }}
                                          disabled={isLoading}
                                      />
                                      </FormControl>
                                      <FormMessage />
                                  </FormItem>
                              )}
                          />
                        </div>
                      </FormItem>
                    <FormField
                      control={dealerForm.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email</FormLabel>
                          <FormControl>
                            <Input type="email" {...field} disabled={isLoading} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={dealerForm.control}
                      name="location"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Location</FormLabel>
                          <FormControl>
                            <Input {...field} disabled={isLoading} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={dealerForm.control}
                      name="aadhar"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Aadhar Number (Optional)</FormLabel>
                          <FormControl>
                            <Input
                              {...field}
                              onChange={(e) => field.onChange(formatAadhar(e.target.value))}
                              disabled={isLoading}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={dealerForm.control}
                      name="terms"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4 shadow">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                              disabled={isLoading}
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <Label>Accept Terms & Conditions</Label>
                            <FormDescription>
                              You agree to our terms of service and privacy policy.
                            </FormDescription>
                            <FormMessage />
                          </div>
                        </FormItem>
                      )}
                    />
                    {error && <p className="text-sm font-medium text-destructive">{error}</p>}
                    <Button type="submit" className="w-full" disabled={isLoading}>
                      {isLoading ? (<><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Sending OTP...</>) : 'Register'}
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </TabsContent>
          <div className="mt-4 text-center text-sm">
            Already have an account?{' '}
            <Link href="/" className="underline">
              Log in
            </Link>
          </div>
        </Tabs>
      )}
    </div>
  );
}

export default function RegisterPage() {
  return (
    <Suspense fallback={<div>Loading...</div>}>
      <RegisterForm />
    </Suspense>
  );
}
