
'use server';

import 'dotenv/config';
import { promises as fs } from 'fs';
import path from 'path';
import { v4 as uuidv4 } from 'uuid';
import type { User } from '@/lib/types';


const usersFilePath = path.join(process.cwd(), 'src', 'lib', 'db', 'users.json');

async function getUsers(): Promise<User[]> {
  try {
    const data = await fs.readFile(usersFilePath, 'utf-8');
    return JSON.parse(data);
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === 'ENOENT') {
      return [];
    }
    throw error;
  }
}

async function saveUsers(users: User[]) {
  await fs.writeFile(usersFilePath, JSON.stringify(users, null, 2), 'utf-8');
}


export async function registerUser(userData: Omit<User, 'id' >) {
  try {
    const users = await getUsers();
    if (users.some(u => u.mobile === userData.mobile && userData.mobile)) {
      return { success: false, error: 'A user with this mobile number already exists.' };
    }

    const newUser: User = {
      ...userData,
      id: uuidv4(),
    };

    users.push(newUser);
    await saveUsers(users);

    return { success: true, user: newUser };
  } catch (error: any) {
    console.error('DB save error:', error);
    let errorMessage = 'An unexpected error occurred during registration.';
     if (error.message) {
        errorMessage = error.message;
     }
    return { success: false, error: errorMessage };
  }
}

export async function checkUserExistsByMobile(mobile: string) {
  try {
    const users = await getUsers();
    const user = users.find((u: { mobile?: string }) => u.mobile === mobile);
    
    if (user) {
      return { success: true, role: user.role };
    } else {
      return { success: false, error: 'This mobile number is not registered.' };
    }
  } catch (error) {
    console.error('Error checking user:', error);
    return { success: false, error: 'A server error occurred. Please try again.' };
  }
}
