
'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  Home,
  ShoppingCart,
  Settings,
  Package,
  GitFork,
  MessageSquare,
  Newspaper,
} from 'lucide-react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { DashboardHeader } from '@/components/header';
import { WaymarkIcon } from '@/components/icons';
import { cn } from '@/lib/utils';

export default function DealerDashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const pathname = usePathname();

  const navLinks = [
    { href: '/dealer/dashboard', icon: Home, label: 'Dashboard' },
    { href: '/dealer/dashboard/holdings', icon: Package, label: 'My Holdings' },
    { href: '/dealer/dashboard/marketplace', icon: ShoppingCart, label: 'Marketplace' },
    { href: '/dealer/dashboard/supply-chain', icon: GitFork, label: 'Supply Chain' },
    { href: '/dashboard/chats', icon: MessageSquare, label: 'Chats' },
    { href: '/dashboard/news-feed', icon: Newspaper, label: 'News Feed' },
  ];

  const settingsLink = { href: '/dashboard/settings', icon: Settings, label: 'Settings' };


  return (
    <div className="flex min-h-screen w-full flex-col bg-muted/40">
      <aside className="fixed inset-y-0 left-0 z-10 hidden w-14 flex-col border-r bg-background sm:flex">
        <TooltipProvider>
          <nav className="flex flex-col items-center gap-4 px-2 sm:py-5">
            <Link
              href="/dealer/dashboard"
              className="group flex h-9 w-9 shrink-0 items-center justify-center gap-2 rounded-full bg-primary text-lg font-semibold text-primary-foreground md:h-8 md:w-8 md:text-base"
              prefetch={false}
            >
              <WaymarkIcon className="h-4 w-4 transition-all group-hover:scale-110" />
              <span className="sr-only">WayMark</span>
            </Link>
            {navLinks.map((link) => (
               <Tooltip key={link.label}>
                <TooltipTrigger asChild>
                  <Link
                    href={link.href}
                    className={cn(
                        'flex h-9 w-9 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:text-foreground md:h-8 md:w-8',
                        pathname === link.href || (link.href !== '/dealer/dashboard' && link.href !== '#' && pathname.startsWith(link.href))
                            ? 'bg-accent text-accent-foreground'
                            : ''
                    )}
                    prefetch={false}
                  >
                    <link.icon className="h-5 w-5" />
                    <span className="sr-only">{link.label}</span>
                  </Link>
                </TooltipTrigger>
                <TooltipContent side="right">{link.label}</TooltipContent>
              </Tooltip>
            ))}
          </nav>
          <nav className="mt-auto flex flex-col items-center gap-4 px-2 sm:py-5">
            <Tooltip>
              <TooltipTrigger asChild>
                <Link
                  href={settingsLink.href}
                  className={cn(
                        'flex h-9 w-9 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:text-foreground md:h-8 md:w-8',
                        pathname.startsWith(settingsLink.href) ? 'bg-accent text-accent-foreground' : ''
                    )}
                  prefetch={false}
                >
                  <Settings className="h-5 w-5" />
                  <span className="sr-only">Settings</span>
                </Link>
              </TooltipTrigger>
              <TooltipContent side="right">Settings</TooltipContent>
            </Tooltip>
          </nav>
        </TooltipProvider>
      </aside>
      <div className="flex flex-col sm:gap-4 sm:py-4 sm:pl-14">
        <DashboardHeader>
        </DashboardHeader>
        <main className="grid flex-1 items-start gap-4 p-4 sm:px-6 sm:py-0 md:gap-8">
          {children}
        </main>
      </div>
    </div>
  );
}
