
'use client';

import { Line, LineChart, CartesianGrid, XAxis, YAxis, Legend } from 'recharts';
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  type ChartConfig,
} from '@/components/ui/chart';
import { IndianRupee } from 'lucide-react';

type SalesChartProps = {
  data: {
    name: string;
    income: number;
    spendings: number;
    profit: number;
    holdingsCount: number;
  }[];
};

const chartConfig = {
  income: {
    label: 'Income',
    color: 'hsl(var(--primary))',
  },
  spendings: {
      label: 'Spendings',
      color: 'hsl(var(--destructive))',
  },
  profit: {
    label: 'Profit',
    color: 'hsl(var(--chart-2))',
  },
  holdingsCount: {
    label: 'Batch Count',
    color: 'hsl(var(--chart-4))',
  },
} satisfies ChartConfig;

export function SalesChart({ data }: SalesChartProps) {
  return (
    <ChartContainer config={chartConfig} className="h-[250px] w-full">
      <LineChart accessibilityLayer data={data}>
        <CartesianGrid vertical={false} />
        <XAxis
          dataKey="name"
          tickLine={false}
          tickMargin={10}
          axisLine={false}
          tickFormatter={(value, index) => {
            if (index % 5 === 0) {
                return value;
            }
            return "";
          }}
        />
        <YAxis
          yAxisId="left"
          tickFormatter={(value) => `₹${Number(value) / 1000}k`}
        />
        <YAxis
          yAxisId="right"
          orientation="right"
          tickFormatter={(value) => `${value}`}
        />
        <ChartTooltip
          cursor={false}
          content={
            <ChartTooltipContent
                formatter={(value, name) => {
                    if (name === 'profit' || name === 'income' || name === 'spendings') {
                        return (
                            <div className="flex items-center">
                                <IndianRupee className="h-4 w-4 mr-1" />
                                <span>{Number(value).toLocaleString()}</span>
                            </div>
                        )
                    }
                    return Number(value).toLocaleString();
                }}
            />
        }
        />
        <Legend />
        <Line dataKey="profit" name="Profit" yAxisId="left" type="monotone" stroke="var(--color-profit)" strokeWidth={2} dot={false} />
        <Line dataKey="income" name="Income" yAxisId="left" type="monotone" stroke="var(--color-income)" strokeWidth={2} dot={false} />
        <Line dataKey="spendings" name="Spendings" yAxisId="left" type="monotone" stroke="var(--color-spendings)" strokeWidth={2} dot={false} />
        <Line dataKey="holdingsCount" name="BatchCount" yAxisId="right" type="step" stroke="var(--color-holdingsCount)" strokeWidth={2} dot={false} />
      </LineChart>
    </ChartContainer>
  );
}
