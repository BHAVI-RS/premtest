
import { Suspense } from 'react';
import { MarketplaceClient } from './client';
import { getListedBatches } from './actions';
import {
  Card,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { SellHoldingsClient } from './sell-client';
import { getDealerHoldings } from './actions';

export default async function MarketplacePage() {
  // In a real app, this would come from the current user's session
  const currentDealerId = 'dealer-1'; 
  
  const listedBatches = await getListedBatches(currentDealerId);
  const dealerHoldings = await getDealerHoldings(currentDealerId);

  return (
    <div className="space-y-6">
       <Card>
        <CardHeader>
          <CardTitle>Marketplace</CardTitle>
          <CardDescription>
            Browse and purchase crop batches from farmers, or sell your holdings to other dealers.
          </CardDescription>
        </CardHeader>
      </Card>

      <Tabs defaultValue="buy">
        <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="buy">Buy From Farmers</TabsTrigger>
            <TabsTrigger value="sell">Sell Your Holdings</TabsTrigger>
        </TabsList>
        <TabsContent value="buy">
             <Suspense fallback={<p>Loading marketplace...</p>}>
                <MarketplaceClient initialBatches={listedBatches} currentDealerId={currentDealerId} />
            </Suspense>
        </TabsContent>
         <TabsContent value="sell">
             <Suspense fallback={<p>Loading form...</p>}>
                <SellHoldingsClient activeHoldings={dealerHoldings} currentDealerId={currentDealerId} />
            </Suspense>
        </TabsContent>
      </Tabs>
    </div>
  );
}
