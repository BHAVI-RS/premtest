
'use client';

import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import React from 'react';
import { useRouter } from 'next/navigation';

import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Loader2, ShoppingCart } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import type { CropBatch } from '@/lib/types';
import { listHoldingForSale } from './actions';

const formSchema = z.object({
  batchId: z.string().min(1, 'You must select a batch to sell.'),
  price: z.coerce.number().min(0.01, 'Price must be greater than zero.'),
  remarks: z.string().optional(),
});

type FormValues = z.infer<typeof formSchema>;

export function SellHoldingsClient({ activeHoldings, currentDealerId }: { activeHoldings: CropBatch[], currentDealerId: string }) {
  const [isLoading, setIsLoading] = React.useState(false);
  const { toast } = useToast();
  const router = useRouter();

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      batchId: '',
      price: 0,
      remarks: '',
    },
  });

  async function onSubmit(values: FormValues) {
    setIsLoading(true);

    const formData = new FormData();
    Object.entries(values).forEach(([key, value]) => {
      formData.append(key, String(value));
    });
    formData.append('dealerId', currentDealerId);
    
    const result = await listHoldingForSale(formData);

    if (result.success) {
      toast({
        title: "Holding Listed!",
        description: result.message,
      });
      // A full page refresh might be easiest to update both buy/sell tabs
      router.refresh(); 
      form.reset();
    } else {
      toast({
        title: "Listing Failed",
        description: result.error,
        variant: "destructive"
      });
    }

    setIsLoading(false);
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Sell Your Holdings</CardTitle>
        <CardDescription>
          List a crop batch from your holdings for other dealers to purchase.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="batchId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Batch to Sell</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a batch from your holdings" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {activeHoldings.length > 0 ? activeHoldings.map(batch => (
                        <SelectItem key={batch.id} value={batch.id}>
                          {batch.cropType} ({batch.variety}) - {batch.quantity}kg
                        </SelectItem>
                      )) : <SelectItem value="-" disabled>No active holdings available to sell</SelectItem>}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="price"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Listing Price (per kg in ₹)</FormLabel>
                  <FormControl>
                    <Input type="number" placeholder="e.g., 28" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="remarks"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Remarks (Optional)</FormLabel>
                  <FormControl>
                    <Textarea placeholder="e.g., 'Stored in optimal conditions, ready for immediate dispatch.'" {...field} />
                  </FormControl>
                  <FormDescription>
                    Add any notes for potential buyers.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="flex justify-end pt-4">
              <Button type="submit" className="w-full md:w-auto" disabled={isLoading || activeHoldings.length === 0}>
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Listing Holding...
                  </>
                ) : (
                  <>
                    <ShoppingCart className="mr-2 h-4 w-4" />
                    List Holding for Sale
                  </>
                )}
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
