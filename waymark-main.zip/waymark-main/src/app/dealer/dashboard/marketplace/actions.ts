
'use server';

import { getCropBatches, saveCropBatches, users, supplyChainEvents, getTransactions, saveTransactions, buildAllChains } from '@/lib/data';
import type { CropBatch, Transaction, SupplyChainEvent } from '@/lib/types';
import { revalidatePath } from 'next/cache';
import { v4 as uuidv4 } from 'uuid';

export async function getListedBatches(currentDealerId: string) {
    const allBatches = await getCropBatches();
    // Show batches listed by farmers OR other dealers, but not the current dealer
    const listedBatches = allBatches.filter(b => b.status === 'listed' && (b.farmerId !== currentDealerId && b.soldTo !== currentDealerId));
    
    return listedBatches
        .map(batch => {
            const seller = users.find(u => u.id === (batch.soldTo || batch.farmerId));
            return {
                ...batch,
                farmerName: seller?.name || 'Unknown Seller',
            };
        });
}

export async function getDealerHoldings(dealerId: string) {
    const allBatches = await getCropBatches();
    const deliveryEvents = supplyChainEvents
        .filter(e => e.actor.id === dealerId && e.type === 'DELIVERY');
    const deliveredBatchIds = new Set(deliveryEvents.map(e => e.batchId));
  
    // Return batches that are in stock (purchased but not yet delivered) and not already listed for sale
    const activeBatches = allBatches.filter(
      batch => batch.soldTo === dealerId && !deliveredBatchIds.has(batch.id) && batch.status !== 'listed'
    );
    return activeBatches;
}


export async function purchaseBatch(batchId: string, dealerId: string, quantityToBuy: number) {
    try {
        const allBatches = await getCropBatches();
        const transactions = await getTransactions();
        const batchIndex = allBatches.findIndex(b => b.id === batchId);
        
        if (batchIndex === -1) throw new Error("Batch not found.");
        
        const originalBatch = allBatches[batchIndex];

        if (originalBatch.status !== 'listed') throw new Error("This batch is not available for sale.");
        if (quantityToBuy <= 0) throw new Error("Quantity must be positive.");
        if (quantityToBuy > originalBatch.quantity) throw new Error("Not enough quantity available for purchase.");

        const sellerId = originalBatch.soldTo || originalBatch.farmerId;
        const seller = users.find(u => u.id === sellerId);
        const buyer = users.find(u => u.id === dealerId);
        if(!seller || !buyer) throw new Error("Seller or buyer not found.");

        const isFullPurchase = quantityToBuy === originalBatch.quantity;
        const purchaseAmount = quantityToBuy * originalBatch.priceInRupees!;

        // This is the batch the dealer will own
        let purchasedBatch: CropBatch;

        if (isFullPurchase) {
            // Dealer buys the entire remaining listed quantity. We can update the existing batch record.
            originalBatch.status = 'sold'; // The seller has sold this batch.
            purchasedBatch = {
                ...originalBatch,
                id: uuidv4(),
                parentBatchId: originalBatch.parentBatchId || originalBatch.id,
                status: 'registered', // It's now 'registered' or 'in-stock' for the buyer.
                soldTo: dealerId, // Ownership transfers to the buyer.
            }
            allBatches.push(purchasedBatch);
            // Mark original as fully sold
            originalBatch.status = 'sold';

        } else {
            // Dealer buys a partial quantity.
            // 1. Reduce quantity of the original listed batch
            originalBatch.quantity -= quantityToBuy;
            
            // 2. Create a new "registered" batch for the dealer
            purchasedBatch = {
                ...originalBatch,
                id: uuidv4(), // New ID for this specific owned portion
                parentBatchId: originalBatch.parentBatchId || originalBatch.id, // Link to the root batch
                quantity: quantityToBuy,
                status: 'registered', // This batch is now "registered" or "in stock" for the dealer
                soldTo: dealerId,
            };
            allBatches.push(purchasedBatch);
        }

        // Create a new transaction record for the purchase
        const newTransaction: Transaction = {
            id: uuidv4(),
            batchId: purchasedBatch.id, // Use the ID of the batch record the dealer now owns
            farmerId: purchasedBatch.farmerId, // Original farmer
            dealerId: dealerId,
            purchaseDate: new Date().toISOString().split('T')[0],
            quantity: quantityToBuy,
            pricePerKgInRupees: purchasedBatch.priceInRupees!,
            totalAmountInRupees: purchaseAmount,
        };
        transactions.push(newTransaction);
        purchasedBatch.transactionId = newTransaction.id;


        // Add a supply chain event for the sale
        const saleEvent: SupplyChainEvent = {
            id: `evt-${purchasedBatch.id}-sale-${uuidv4()}`,
            batchId: purchasedBatch.parentBatchId || purchasedBatch.id, // Event is part of the parent chain
            type: 'SALE',
            timestamp: new Date().toISOString(),
            title: `Sold to Dealer ${buyer.name}`,
            description: `${quantityToBuy}kg of batch sold from ${seller.name} to ${buyer.name} for ₹${purchaseAmount.toLocaleString()}`,
            actor: { id: seller.id, name: seller.name, role: seller.role as 'FARMER' | 'DEALER' },
            costInRupees: purchaseAmount,
        };
        supplyChainEvents.push(saleEvent);
        
        await saveCropBatches(allBatches);
        await saveTransactions(transactions);
        await buildAllChains();

        revalidatePath('/dealer/dashboard/marketplace');
        revalidatePath('/dealer/dashboard/holdings');
        revalidatePath('/dashboard/my-batches');
        revalidatePath('/dashboard');
        revalidatePath('/dealer/dashboard');

        return { success: true, message: `Successfully purchased ${quantityToBuy}kg of ${originalBatch.cropType}.` };

    } catch (error: any) {
        console.error('Failed to purchase batch:', error);
        return { success: false, error: error.message || 'An unknown error occurred.' };
    }
}

export async function listHoldingForSale(formData: FormData) {
    const rawFormData = Object.fromEntries(formData.entries());
    const batchId = rawFormData.batchId as string;
    const price = Number(rawFormData.price);
    const remarks = rawFormData.remarks as string;
    const dealerId = rawFormData.dealerId as string;

    if(!batchId || !price || !dealerId) {
        return { success: false, error: "Missing required form data." };
    }

    try {
        const allBatches = await getCropBatches();
        const batchIndex = allBatches.findIndex(b => b.id === batchId);

        if (batchIndex === -1) {
            throw new Error('Batch not found in holdings.');
        }
        
        const batch = allBatches[batchIndex];

        // Ensure the dealer actually owns this batch and it's not delivered yet
        if(batch.soldTo !== dealerId) {
            return { success: false, error: "You do not own this batch." };
        }
        
        if(batch.status === 'listed') {
            return { success: false, error: "This batch is already listed for sale." };
        }

        // Update the batch to be listed
        batch.status = 'listed';
        batch.priceInRupees = price;
        // The original farmerId stays. The seller is identified by the `soldTo` field.
        
        await saveCropBatches(allBatches);
        
        revalidatePath('/dealer/dashboard/marketplace');
        revalidatePath('/dealer/dashboard/holdings');

        return { success: true, message: `${batch.quantity}kg of ${batch.cropType} listed for sale.` };
    } catch (error: any) {
        console.error('Failed to list holding:', error);
        return { success: false, error: error.message || 'An unknown error occurred.' };
    }
}
