
'use client';

import type { CropBatch } from '@/lib/types';
import React from 'react';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { IndianRupee, ShoppingCart, Tractor, Weight, Calendar, GitFork, Info, Truck, Package, Quote, Eye, Search } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { purchaseBatch } from './actions';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogClose,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import Link from 'next/link';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';

type MarketplaceBatch = CropBatch & { farmerName: string };

export function MarketplaceClient({ initialBatches, currentDealerId }: { initialBatches: MarketplaceBatch[], currentDealerId: string }) {
  const [searchTerm, setSearchTerm] = React.useState('');
  const [isLoading, setIsLoading] = React.useState<string | null>(null);
  const [showConfirmDialog, setShowConfirmDialog] = React.useState(false);
  const [selectedBatch, setSelectedBatch] = React.useState<MarketplaceBatch | null>(null);
  const [quantityToBuy, setQuantityToBuy] = React.useState<number>(0);
  const [purchaseError, setPurchaseError] = React.useState<string>('');
  const { toast } = useToast();

  const filteredBatches = React.useMemo(() => {
    if (!searchTerm) return initialBatches;
    return initialBatches.filter(batch => 
      batch.cropType.toLowerCase().includes(searchTerm.toLowerCase()) ||
      batch.variety.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [searchTerm, initialBatches]);

  const handlePurchaseClick = (batch: MarketplaceBatch) => {
    setSelectedBatch(batch);
    setQuantityToBuy(batch.quantity); // Default to full quantity
    setPurchaseError('');
    setShowConfirmDialog(true);
  };

  const handleConfirmPurchase = async () => {
    if (!selectedBatch) return;

    if (quantityToBuy <= 0) {
        setPurchaseError('Quantity must be greater than zero.');
        return;
    }
    if (quantityToBuy > selectedBatch.quantity) {
        setPurchaseError(`Cannot purchase more than the available ${selectedBatch.quantity}kg.`);
        return;
    }
    
    setPurchaseError('');
    setIsLoading(selectedBatch.id);

    const result = await purchaseBatch(selectedBatch.id, currentDealerId, quantityToBuy);
    
    if (result.success) {
      toast({
        title: 'Purchase Successful!',
        description: result.message,
      });
      // Refresh the list to show updated quantities or remove if sold out
      // A full page refresh is simpler than trying to update state manually here
      window.location.reload(); 
    } else {
      toast({
        title: 'Purchase Failed',
        description: result.error,
        variant: 'destructive',
      });
    }

    setIsLoading(null);
    setShowConfirmDialog(false);
    setSelectedBatch(null);
  };
  
  return (
    <>
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Buy From Farmers</CardTitle>
          <CardDescription>Search and browse available crop batches from farmers.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                  type="search"
                  placeholder="Search for a crop (e.g., Wheat, Corn)..."
                  className="w-full rounded-lg bg-background pl-8"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
              />
          </div>
        </CardContent>
      </Card>

      {filteredBatches.length === 0 ? (
        <Card className="text-center py-12">
            <CardContent>
                <h3 className="text-xl font-semibold">No Batches Found</h3>
                <p className="text-muted-foreground mt-2">
                  {searchTerm ? `Your search for "${searchTerm}" did not match any batches.` : 'There are currently no crop batches listed for sale.'}
                </p>
            </CardContent>
        </Card>
      ) : (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {filteredBatches.map(batch => (
            <Card key={batch.id} className="flex flex-col">
              <CardHeader>
                <div className="flex justify-between items-start">
                  <CardTitle>{batch.cropType} ({batch.variety})</CardTitle>
                  <div className="flex items-center text-lg font-bold text-primary">
                    <IndianRupee className="h-5 w-5" />
                    <span>{batch.priceInRupees?.toLocaleString()}/kg</span>
                  </div>
                </div>
                <CardDescription className="flex items-center gap-2 pt-1">
                  <Tractor className="h-4 w-4" /> Sold by {batch.farmerName}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4 flex-grow">
                <div className="flex items-center gap-2 text-sm">
                    <Weight className="h-4 w-4 text-muted-foreground" />
                    <span><span className="font-semibold">{batch.quantity.toLocaleString()} kg</span> available</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <span>Harvested on {new Date(batch.harvestDate).toLocaleDateString('en-GB')}</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                    <Info className="h-4 w-4 text-muted-foreground" />
                    <span>Quality Score: <span className="font-semibold">{batch.qualityScore}</span></span>
                </div>
              </CardContent>
              <CardFooter className="flex gap-2 border-t pt-4 mt-auto">
                <Dialog>
                  <DialogTrigger asChild>
                    <Button variant="outline" className="w-full">
                      <Eye className="mr-2 h-4 w-4" />
                      Show Details
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-md">
                    <DialogHeader>
                      <DialogTitle>{batch.cropType} ({batch.variety})</DialogTitle>
                      <DialogDescription>
                        Full details for batch ID: <span className="font-mono text-xs">{batch.id.substring(0,14)}...</span>
                      </DialogDescription>
                    </DialogHeader>
                    <div className="grid gap-4 py-4">
                      <div className="flex justify-between items-center">
                        <span className="text-muted-foreground">Price</span>
                        <span className="font-semibold flex items-center"><IndianRupee className="h-4 w-4 mr-1" />{batch.priceInRupees}/kg</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-muted-foreground">Available Quantity</span>
                        <span className="font-semibold">{batch.quantity} kg</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-muted-foreground">Quality Score</span>
                        <Badge variant="secondary">{batch.qualityScore}</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-muted-foreground">Seller</span>
                        <span className="font-semibold">{batch.farmerName}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-muted-foreground">Harvest Date</span>
                        <span className="font-semibold">{new Date(batch.harvestDate).toLocaleDateString('en-GB')}</span>
                      </div>
                      <Separator />
                      <div className="space-y-3">
                        {batch.deliveryOption === 'delivery' && (
                          <div className="flex items-start gap-3 text-sm">
                            <Truck className="h-5 w-5 text-muted-foreground mt-0.5 flex-shrink-0" />
                            <div>
                              <span className="font-semibold">Delivery Available</span>
                              <p className="text-xs text-muted-foreground">Within {batch.deliveryRadius} km. Charges: ₹{batch.deliveryCharges}/km.</p>
                            </div>
                          </div>
                        )}
                        {batch.deliveryOption === 'takeaway' && (
                          <div className="flex items-start gap-3 text-sm">
                            <Package className="h-5 w-5 text-muted-foreground mt-0.5 flex-shrink-0" />
                            <div>
                              <span className="font-semibold">Takeaway Only</span>
                              <p className="text-xs text-muted-foreground">From: {batch.takeawayAddress}</p>
                            </div>
                          </div>
                        )}
                        {batch.remarks && (
                          <div className="flex items-start gap-3 text-sm">
                            <Quote className="h-5 w-5 text-muted-foreground mt-0.5 flex-shrink-0" />
                            <div>
                              <span className="font-semibold">Farmer's Remarks</span>
                              <p className="text-xs text-muted-foreground italic">&quot;{batch.remarks}&quot;</p>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                    <DialogFooter className="sm:justify-between gap-2">
                        <Button variant="ghost" asChild>
                            <Link href={`/dealer/dashboard/supply-chain/${batch.parentBatchId || batch.id}?userId=${currentDealerId}`} target="_blank">
                                <GitFork className="mr-2 h-4 w-4" />
                                View Full Trace
                            </Link>
                        </Button>
                        <DialogClose asChild>
                            <Button type="button">
                                Close
                            </Button>
                      </DialogClose>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>

                <Button 
                    className="w-full" 
                    onClick={() => handlePurchaseClick(batch)}
                    disabled={!!isLoading}
                >
                  {isLoading === batch.id ? 'Processing...' : (
                    <>
                      <ShoppingCart className="mr-2 h-4 w-4" />
                      Buy
                    </>
                  )}
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}
    
      <AlertDialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
          <AlertDialogContent>
              <AlertDialogHeader>
              <AlertDialogTitle>Confirm Purchase</AlertDialogTitle>
              <AlertDialogDescription>
                  You are purchasing from batch ID: <span className="font-mono text-xs">{selectedBatch?.id.substring(0,10)}...</span>
              </AlertDialogDescription>
              </AlertDialogHeader>
              <div className="space-y-4">
                  <div className="grid gap-2">
                      <Label htmlFor="quantity">Quantity to Buy (kg)</Label>
                      <Input 
                          id="quantity"
                          type="number"
                          value={quantityToBuy}
                          onChange={(e) => setQuantityToBuy(Number(e.target.value))}
                          max={selectedBatch?.quantity}
                          min={1}
                      />
                      {purchaseError && <p className="text-sm text-destructive">{purchaseError}</p>}
                  </div>
                  <div className="text-lg font-bold text-center">
                      Total Cost: ₹{((quantityToBuy || 0) * (selectedBatch?.priceInRupees || 0)).toLocaleString()}
                  </div>
              </div>
              <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={handleConfirmPurchase} disabled={isLoading === selectedBatch?.id}>
                  {isLoading === selectedBatch?.id ? 'Processing...' : 'Confirm & Buy'}
              </AlertDialogAction>
              </AlertDialogFooter>
          </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
