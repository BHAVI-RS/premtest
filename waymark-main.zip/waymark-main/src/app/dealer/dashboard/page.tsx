

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Award, Trophy, Package, ArrowRight, IndianRupee, ShoppingCart } from 'lucide-react';
import WaymarkScoreGauge from '@/components/ui/waymark-score-gauge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { users, supplyChainEvents, getCropBatches, getTransactions } from '@/lib/data';
import type { User } from '@/lib/types';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { SalesChart } from './sales-chart';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { ScrollArea } from '@/components/ui/scroll-area';

async function processSalesData() {
    const days = Array.from({ length: 30 }, (_, i) => {
        const d = new Date();
        d.setDate(d.getDate() - i);
        return {
            name: d.toLocaleDateString('en-GB', { day: '2-digit', month: '2-digit' }),
            date: d.toISOString().split('T')[0],
            income: 0,
            spendings: 0,
            profit: 0,
            holdingsCount: 0,
        };
    }).reverse();

    const dealerId = 'dealer-1';
    const transactions = await getTransactions();

    // Calculate spendings from purchases
    transactions.forEach(tx => {
        if (tx.dealerId === dealerId) {
            const purchaseDateStr = tx.purchaseDate;
            const dayData = days.find(d => d.date === purchaseDateStr);
            if (dayData) {
                dayData.spendings += tx.totalAmountInRupees;
            }
        }
    });

    // Calculate income from sales to retailers
    supplyChainEvents.forEach(event => {
        if (event.type === 'DELIVERY' && event.actor.id === dealerId && event.costInRupees) {
             const deliveryDateStr = new Date(event.timestamp).toISOString().split('T')[0];
             const dayData = days.find(d => d.date === deliveryDateStr);
             if (dayData) {
                dayData.income += event.costInRupees;
             }
        }
    });
    
    // Calculate profit and ensure it's not negative
    days.forEach(d => {
        d.profit = Math.max(0, d.income - d.spendings);
    });
    
    // Simulate a more realistic holdings count
    let currentHoldings = 25; // Start with a realistic base
    days.forEach((day, index) => {
        // Simulate daily fluctuation
        const dailyChange = Math.floor(Math.random() * 5) - 2; // -2 to +2
        currentHoldings += dailyChange;

        // Add a bigger change every few days to simulate large trades
        if (index > 0 && index % 5 === 0) {
            currentHoldings += (Math.random() > 0.5 ? 1 : -1) * (Math.floor(Math.random() * 5) + 3);
        }

        // Ensure holdings stay within a realistic range
        if (currentHoldings < 20) currentHoldings = 20;
        if (currentHoldings > 40) currentHoldings = 40;
        
        day.holdingsCount = currentHoldings;

        // Correlate profit/loss with holdings changes for realism, ensuring profit doesn't go negative
        if(dailyChange > 0) { // Increase in holdings means spending
            day.profit = Math.max(0, day.profit - (dailyChange * 50000)); // Assume avg batch cost
        } else if (dailyChange < 0) { // Decrease means income
            day.profit += Math.abs(dailyChange) * 65000; // Assume avg sale price
        }
    });


    return days;
}


export default async function DealerDashboardPage() {
  const waymarkScore = 92;
  const dealerId = 'dealer-1';

  const leaderboard: (User & { score: number })[] = users
    .filter(u => u.role === 'dealer')
    .slice(0, 3)
    .map((u, i) => ({
      ...u,
      score: 95 - i * 4,
    }));
  
  const allBatches = await getCropBatches();
  const transactions = await getTransactions();
  const dealerTransactions = transactions.filter(t => t.dealerId === dealerId);
  const deliveryEvents = supplyChainEvents.filter(e => e.type === 'DELIVERY' && e.actor.id === dealerId);
  
  const purchasedBatchIds = new Set(dealerTransactions.map(t => t.batchId));
  const deliveredBatchIds = new Set(deliveryEvents.map(e => e.batchId));
  
  const activeHoldingsCount = allBatches.filter(
      batch => batch.soldTo === dealerId && !deliveredBatchIds.has(batch.id)
  ).length;

  const salesData = await processSalesData();

  const recentTransactions = dealerTransactions
    .sort((a, b) => new Date(b.purchaseDate).getTime() - new Date(a.purchaseDate).getTime())
    .slice(0, 5);
    
  const dealerOwnedBatchIds = new Set(allBatches.filter(b => b.soldTo === dealerId).map(b => b.parentBatchId || b.id));
  const retailSales = supplyChainEvents
    .filter(e => e.type === 'SALE' && e.actor.role === 'RETAILER' && dealerOwnedBatchIds.has(e.batchId));


  return (
    <div className="grid gap-6">
       <h1 className="text-3xl font-bold tracking-tight">Dealer Dashboard</h1>
       <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
         <Card className="lg:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-base font-medium">Waymark Score</CardTitle>
            <Award className="h-5 w-5 text-muted-foreground" />
          </CardHeader>
          <CardContent className="grid md:grid-cols-2 gap-4 items-center">
            <div>
              <WaymarkScoreGauge score={waymarkScore} />
              <p className="text-xs text-center text-muted-foreground mt-2">
                  Your score reflects your transaction history & reliability.
              </p>
            </div>
            <div className="space-y-4">
              <h4 className="flex items-center font-semibold text-base"><Trophy className="h-5 w-5 mr-2 text-yellow-500" />Leaderboard</h4>
              <ul className="space-y-3">
                {leaderboard.map((dealer, index) => (
                  <li key={dealer.id} className="flex items-center gap-3">
                    <span className="font-bold text-lg text-muted-foreground w-4">
                      {index + 1}
                    </span>
                    <Avatar className="h-9 w-9">
                      <AvatarFallback>{dealer.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <p className="text-sm font-medium leading-none">{dealer.name}</p>
                      <p className="text-xs text-muted-foreground">{dealer.location}</p>
                    </div>
                    <div className="font-bold text-primary">{dealer.score}</div>
                  </li>
                ))}
              </ul>
            </div>
          </CardContent>
        </Card>
        <Card className="flex flex-col">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-base font-medium">
                  Current Holdings
                </CardTitle>
                <Package className="h-5 w-5 text-muted-foreground" />
            </CardHeader>
            <CardContent className="flex-grow flex flex-col justify-between">
              <div>
                <div className="text-4xl font-bold">{activeHoldingsCount}</div>
                <p className="text-xs text-muted-foreground">
                    active batches in stock
                </p>
              </div>
              <Button className="mt-4 w-full" asChild>
                <Link href="/dealer/dashboard/holdings">
                    Show Holdings <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </CardContent>
        </Card>
      </div>

       <Card>
          <CardHeader>
            <CardTitle>30-Day Performance Report</CardTitle>
            <CardDescription>A summary of your holdings and profit/loss over the last 30 days.</CardDescription>
          </CardHeader>
          <CardContent>
            <SalesChart data={salesData} />
          </CardContent>
        </Card>
        
        <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Recent Transactions</CardTitle>
            <CardDescription>Your recent crop purchases from farmers.</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Crop</TableHead>
                  <TableHead>Bought From</TableHead>
                  <TableHead className="text-right">Amount</TableHead>
                  <TableHead className="text-right">Date</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {recentTransactions.map((tx) => {
                  const txBatch = allBatches.find(b => b.id === tx.batchId);
                  const rootBatch = allBatches.find(b => b.id === txBatch?.parentBatchId) || txBatch;
                  const farmer = users.find(u => u.id === tx.farmerId);
                  return (
                    <TableRow key={tx.id}>
                      <TableCell>
                        <div className="font-medium">{rootBatch?.cropType}</div>
                        <div className="text-sm text-muted-foreground">{tx.quantity.toLocaleString()} kg</div>
                      </TableCell>
                      <TableCell>{farmer?.name}</TableCell>
                       <TableCell className="text-right font-medium">
                        <div className="flex items-center justify-end">
                            <IndianRupee className="h-4 w-4 mr-1" />
                            {tx.totalAmountInRupees.toLocaleString()}
                        </div>
                      </TableCell>
                      <TableCell className="text-right">{new Date(tx.purchaseDate).toLocaleDateString('en-GB')}</TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Card className="flex flex-col">
          <CardHeader>
            <CardTitle>Recent Retail Sales</CardTitle>
            <CardDescription>
              Track when your purchased produce reaches the customer.
            </CardDescription>
          </CardHeader>
          <CardContent className="p-0 flex-grow">
            <div className="relative">
              <div className="max-h-96 overflow-y-auto">
                <Table>
                  <TableHeader className="sticky top-0 bg-background z-10">
                    <TableRow>
                      <TableHead>Crop</TableHead>
                      <TableHead>Retailer</TableHead>
                      <TableHead className="hidden sm:table-cell">Date</TableHead>
                      <TableHead className="text-right">Action</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {retailSales.length > 0 ? (
                      retailSales.map((sale) => {
                        const rootBatch = allBatches.find(b => b.id === sale.batchId);
                        return (
                          <TableRow key={sale.id}>
                            <TableCell>
                              <div className="font-medium">{rootBatch?.cropType}</div>
                              <div className="text-sm text-muted-foreground font-mono text-xs">
                                <Link
                                  href={`/dealer/dashboard/supply-chain/${rootBatch?.id}?userId=${dealerId}&saleId=${sale.id}`}
                                  className="text-primary underline hover:text-primary/80"
                                >
                                  {`${rootBatch?.id.substring(0, 14)}...`}
                                </Link>
                              </div>
                            </TableCell>
                            <TableCell>{sale.actor.name}</TableCell>
                            <TableCell className="hidden sm:table-cell">
                              {new Date(sale.timestamp).toLocaleDateString('en-GB')}
                            </TableCell>
                            <TableCell className="text-right">
                              <Button variant="outline" size="sm" asChild>
                                <Link href={`/dealer/dashboard/supply-chain/${sale.batchId}?userId=${dealerId}&saleId=${sale.id}`}>
                                  View Trace
                                </Link>
                              </Button>
                            </TableCell>
                          </TableRow>
                        );
                      })
                    ) : (
                      <TableRow>
                        <TableCell
                          colSpan={4}
                          className="h-24 text-center"
                        >
                          No retail sales yet.
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

    </div>
  );
}

    