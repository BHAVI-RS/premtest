

import { SupplyChainTimeline } from '@/components/supply-chain-timeline';

export default async function DealerSupplyChainTracePage({ params, searchParams }: { params: { id: string }, searchParams: { userId: string, saleId?: string } }) {
  
  const backLink = '/dealer/dashboard/holdings';

  return (
    <div className="container mx-auto max-w-4xl py-8">
       <SupplyChainTimeline 
            batchId={params.id} 
            currentUserId={searchParams.userId || 'dealer-1'} 
            saleId={searchParams.saleId}
            showTitle={true}
            backLink={backLink}
        />
    </div>
  );
}

