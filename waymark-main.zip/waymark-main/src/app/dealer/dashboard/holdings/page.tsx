
import {
    Card,
    CardContent,
    CardDescription,
    CardHeader,
    CardTitle,
  } from '@/components/ui/card';
  import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
  } from '@/components/ui/table';
  import { Badge } from '@/components/ui/badge';
  import { getCropBatches, getTransactions, supplyChainEvents } from '@/lib/data';
  import { Button } from '@/components/ui/button';
  import { File } from 'lucide-react';
  import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
  import Link from 'next/link';
  
  export default async function MyHoldingsPage() {
    // This logic assumes a logged-in dealer, here hardcoded to 'dealer-1'
    const dealerId = 'dealer-1';
  
    const allBatches = await getCropBatches();
    const allTransactions = await getTransactions();
    
    // 1. Find all batches the dealer ever purchased.
    const dealerPurchasedBatches = allBatches.filter(b => b.soldTo === dealerId);

    // 2. Get the unique set of original PARENT batch IDs the dealer owns or has owned.
    const dealerOwnedParentBatchIds = new Set(dealerPurchasedBatches.map(b => b.parentBatchId || b.id));

    // 3. Get all DELIVERY events performed by the current dealer. These events are on the PARENT batch ID.
    const dealerDeliveryEvents = supplyChainEvents
        .filter(e => e.actor.id === dealerId && e.type === 'DELIVERY');
    const deliveredParentBatchIds = new Set(dealerDeliveryEvents.map(e => e.batchId));
    
    // 4. Active holdings are batches whose parent ID is owned but NOT delivered.
    const activeParentBatchIds = new Set([...dealerOwnedParentBatchIds].filter(id => !deliveredParentBatchIds.has(id)));
    const activeBatches = dealerPurchasedBatches.filter(b => activeParentBatchIds.has(b.parentBatchId || b.id));
    
    // 5. Sold holdings are batches whose parent ID is owned AND has been delivered.
    const soldParentBatchIds = new Set([...dealerOwnedParentBatchIds].filter(id => deliveredParentBatchIds.has(id)));
    const soldBatches = dealerPurchasedBatches.filter(b => soldParentBatchIds.has(b.parentBatchId || b.id));
  
    return (
      <Tabs defaultValue="active">
        <div className="flex items-center">
          <TabsList>
            <TabsTrigger value="active">Active</TabsTrigger>
            <TabsTrigger value="sold">Sold</TabsTrigger>
          </TabsList>
          <div className="ml-auto flex items-center gap-2">
            <Button size="sm" variant="outline" className="h-8 gap-1">
              <File className="h-3.5 w-3.5" />
              <span className="sr-only sm:not-sr-only sm:whitespace-nowrap">
                Export
              </span>
            </Button>
          </div>
        </div>
        <TabsContent value="active">
          <Card>
            <CardHeader>
              <CardTitle>Active Holdings</CardTitle>
              <CardDescription>
                Crop batches you currently have in stock.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Batch ID</TableHead>
                    <TableHead>Crop</TableHead>
                    <TableHead>Quantity</TableHead>
                    <TableHead>Purchase Date</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {activeBatches.length > 0 ? activeBatches.map((batch) => {
                    const transaction = allTransactions.find(t => t.batchId === batch.id);
                    return (
                    <TableRow key={batch.id}>
                      <TableCell className="font-mono text-xs">
                         <Link href={`/dealer/dashboard/supply-chain/${batch.parentBatchId || batch.id}?userId=${dealerId}`} className="text-blue-600 underline hover:text-blue-800">
                          {`${(batch.id).substring(0,10)}...`}
                        </Link>
                      </TableCell>
                      <TableCell>{batch.cropType}</TableCell>
                      <TableCell>{batch.quantity} kg</TableCell>
                      <TableCell>
                        {transaction ? new Date(transaction.purchaseDate).toLocaleDateString('en-GB') : 'N/A'}
                      </TableCell>
                      <TableCell>
                        <Badge variant="secondary">In Stock</Badge>
                      </TableCell>
                      <TableCell>
                         <Button variant="outline" size="sm" asChild>
                          <Link href={`/dealer/dashboard/supply-chain/${batch.parentBatchId || batch.id}?userId=${dealerId}`}>View Trace</Link>
                        </Button>
                      </TableCell>
                    </TableRow>
                  )}) : (
                    <TableRow>
                      <TableCell colSpan={6} className="h-24 text-center">
                        No active batches in your holdings.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="sold">
        <Card>
            <CardHeader>
              <CardTitle>Sold Holdings</CardTitle>
              <CardDescription>
                Crop batches you have already sold and delivered to retailers.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Batch ID</TableHead>
                    <TableHead>Crop</TableHead>
                    <TableHead>Quantity</TableHead>
                    <TableHead>Purchase Date</TableHead>
                    <TableHead>Delivery Date</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {soldBatches.length > 0 ? soldBatches.map((batch) => {
                    const transaction = allTransactions.find(t => t.batchId === batch.id);
                    const deliveryEvent = dealerDeliveryEvents.find(e => e.batchId === (batch.parentBatchId || batch.id));
                    return (
                    <TableRow key={batch.id}>
                      <TableCell className="font-mono text-xs">
                        <Link href={`/dealer/dashboard/supply-chain/${batch.parentBatchId || batch.id}?userId=${dealerId}`} className="text-blue-600 underline hover:text-blue-800">
                          {`${(batch.id).substring(0,10)}...`}
                        </Link>
                      </TableCell>
                      <TableCell>{batch.cropType}</TableCell>
                      <TableCell>{batch.quantity} kg</TableCell>
                      <TableCell>
                        {transaction ? new Date(transaction.purchaseDate).toLocaleDateString('en-GB') : 'N/A'}
                      </TableCell>
                       <TableCell>
                        {deliveryEvent ? new Date(deliveryEvent.timestamp).toLocaleDateString('en-GB') : 'N/A'}
                      </TableCell>
                      <TableCell>
                         <Button variant="outline" size="sm" asChild>
                          <Link href={`/dealer/dashboard/supply-chain/${batch.parentBatchId || batch.id}?userId=${dealerId}`}>View Trace</Link>
                        </Button>
                      </TableCell>
                    </TableRow>
                  )}) : (
                    <TableRow>
                      <TableCell colSpan={6} className="h-24 text-center">
                        No sold batches yet.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    );
  }
  
  
  
