'use client';

import { RadialBar, RadialBarChart, PolarAngleAxis, ResponsiveContainer } from 'recharts';

type WaymarkScoreGaugeProps = {
  score: number;
};

const WaymarkScoreGauge = ({ score }: WaymarkScoreGaugeProps) => {
  const data = [{ name: 'score', value: score }];

  return (
    <ResponsiveContainer width="100%" height={160}>
      <RadialBarChart
        innerRadius="70%"
        outerRadius="100%"
        data={data}
        startAngle={180}
        endAngle={0}
        barSize={25}
      >
        <PolarAngleAxis
          type="number"
          domain={[0, 100]}
          angleAxisId={0}
          tick={false}
        />
        <RadialBar
          background
          dataKey="value"
          angleAxisId={0}
          fill="hsl(var(--primary))"
          cornerRadius={12}
        />
         <text
          x="50%"
          y="75%"
          textAnchor="middle"
          dominantBaseline="middle"
          className="text-4xl font-bold fill-foreground"
        >
          {score}
        </text>
        <text
          x="50%"
          y="95%"
          textAnchor="middle"
          dominantBaseline="middle"
          className="text-sm fill-muted-foreground"
        >
          out of 100
        </text>
      </RadialBarChart>
    </ResponsiveContainer>
  );
};

export default WaymarkScoreGauge;
