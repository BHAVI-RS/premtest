import type { SVGProps } from 'react';

export function WaymarkIcon(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="M12 22c-5 0-9-2.5-9-7s4-10 9-10 9 5.5 9 10-4 7-9 7Z" />
      <path d="M12 10c-5 0-7-2.5-7-5s2-5 7-5 7 2.5 7 5-2 5-7 5Z" />
      <path d="M12 22V2" />
    </svg>
  );
}
