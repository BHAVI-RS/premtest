

import { getCropBatches, getFarmerById, getEventsForBatch, getEventById, SupplyChainEvent } from '@/lib/data';
import { notFound } from 'next/navigation';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { Home, Tractor, Package, ShoppingCart, Truck, Store, Thermometer, Droplets, MapPin, CheckCircle, IndianRupee, User, ShieldCheck, Warehouse } from 'lucide-react';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

function getIconForEventType(type: SupplyChainEvent['type'], actorRole: SupplyChainEvent['actor']['role']) {
  if (type === 'SALE' && actorRole === 'RETAILER') {
    return <User className="h-6 w-6 text-primary" />;
  }

  switch (type) {
    case 'HARVEST':
      return <Tractor className="h-6 w-6 text-primary" />;
    case 'STORAGE':
      return <Warehouse className="h-6 w-6 text-primary" />;
    case 'TRANSIT':
      return <Truck className="h-6 w-6 text-primary" />;
    case 'SALE':
      return <ShoppingCart className="h-6 w-6 text-primary" />;
    case 'DELIVERY':
      return <Store className="h-6 w-6 text-primary" />;
    default:
      return <CheckCircle className="h-6 w-6 text-primary" />;
  }
}

function IoTDataDisplay({ iotData }: { iotData: SupplyChainEvent['iotData'] }) {
  if (!iotData) return null;
  return (
    <div className="mt-2 flex gap-4 text-xs text-muted-foreground">
      <div className="flex items-center gap-1">
        <Thermometer className="h-4 w-4" />
        <span>{iotData.temperature}°C</span>
      </div>
      <div className="flex items-center gap-1">
        <Droplets className="h-4 w-4" />
        <span>{iotData.humidity}%</span>
      </div>
      <div className="flex items-center gap-1">
        <MapPin className="h-4 w-4" />
        <span>{iotData.location}</span>
      </div>
    </div>
  );
}

function TimelineStep({ event, isLast = false, currentUserId, prorationFactor = 1 }: { event: SupplyChainEvent, isLast?: boolean, currentUserId: string, prorationFactor?: number }) {
  const isCurrentUser = event.actor.id === currentUserId;

  let eventTitle = event.title;
  let eventActor = `by ${event.actor.name} (${event.actor.role})`;
  
  if(event.type === 'SALE' && event.actor.role === 'FARMER') {
    eventTitle = `Sold to Dealer`;
  }

  if (isCurrentUser) {
     if(isCurrentUser && event.actor.role !== 'FARMER') {
         eventActor = `by ${event.actor.name} (You)`;
     }
    if (event.type === 'SALE' && event.actor.role === 'DEALER') {
        eventTitle = 'You purchased this batch';
    }
    if (event.type === 'DELIVERY' && event.actor.role === 'DEALER') {
        eventTitle = 'You delivered this batch';
    }
     if (event.type === 'HARVEST' && event.actor.role === 'FARMER') {
        eventTitle = 'You harvested this batch';
        eventActor = `by ${event.actor.name} (You)`;
    }
  }
  
  const proratedCost = event.costInRupees != null ? event.costInRupees * prorationFactor : undefined;


  return (
    <div className="relative flex items-start gap-x-4">
      {!isLast && <div className="absolute left-6 top-7 h-full w-px bg-border -ml-px" />}
      <div className="flex h-12 w-12 flex-none items-center justify-center rounded-lg bg-secondary">
        {getIconForEventType(event.type, event.actor.role)}
      </div>
      <div className="flex-grow pt-1">
        <div className="flex justify-between items-start">
          <div>
            <p className="font-semibold text-foreground">{eventTitle}</p>
            <p className="mt-1 text-sm text-muted-foreground">{event.description}</p>
            <p className="mt-1 text-xs text-muted-foreground">{eventActor}</p>
            <IoTDataDisplay iotData={event.iotData} />
          </div>
          <div className="text-right flex-shrink-0 ml-4">
             <div className="flex items-center justify-end gap-1.5 text-xs text-green-600 font-medium mb-1">
                <ShieldCheck className="h-4 w-4" />
                <span>Verified</span>
             </div>
            <p className="text-xs text-muted-foreground">{new Date(event.timestamp).toLocaleString('en-GB')}</p>
            {proratedCost != null && (
              <div className="mt-1">
                <div className="text-sm font-semibold text-primary flex items-center justify-end">
                    <IndianRupee className="h-4 w-4 mr-1" />
                    <span>
                    {proratedCost.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
                    </span>
                </div>
                 {prorationFactor < 1 && <p className="text-xs text-muted-foreground">(Prorated)</p>}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export async function SupplyChainTimeline({ batchId, currentUserId, saleId, showTitle, backLink }: { batchId: string, currentUserId: string, saleId?: string, showTitle?: boolean, backLink?: string }) {
  const cropBatches = await getCropBatches();
  const batch = cropBatches.find(b => b.id === batchId || b.parentBatchId === batchId);

  if (!batch) {
    return (
        <Card>
            <CardHeader>
                <CardTitle>Batch Not Found</CardTitle>
                <CardDescription>The requested batch ID could not be found.</CardDescription>
            </CardHeader>
        </Card>
    );
  }
  
  const rootBatchId = batch.parentBatchId || batch.id;
  const rootBatch = cropBatches.find(b => b.id === rootBatchId) || batch;

  const finalSaleEvent = saleId ? getEventById(saleId) : null;
  const prorationFactor = (finalSaleEvent && finalSaleEvent.quantity && rootBatch.originalQuantity && rootBatch.originalQuantity > 0)
    ? finalSaleEvent.quantity / rootBatch.originalQuantity
    : (batch.quantity && rootBatch.originalQuantity) ? batch.quantity / rootBatch.originalQuantity : 1;

  const farmer = getFarmerById(rootBatch.farmerId);
  const events = await getEventsForBatch(batch.id);
  
  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-start">
          <div>
            {showTitle && <CardTitle className="text-3xl">Supply Chain Trace</CardTitle>}
            <CardDescription className="font-mono text-xs pt-1">
              Batch ID: <Link href={`/dashboard/supply-chain/${rootBatch.id}?userId=${currentUserId}`} className="text-blue-600 underline">{rootBatch.id}</Link>
            </CardDescription>
          </div>
           {backLink && (
            <Button asChild variant="outline">
              <Link href={backLink}>Go Back</Link>
            </Button>
           )}
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid gap-4 md:grid-cols-3 mb-8">
          <div className="flex items-center gap-4 rounded-lg border p-4">
            <Tractor className="h-8 w-8 text-primary" />
            <div>
              <p className="text-sm text-muted-foreground">Farmer</p>
              <p className="font-semibold">{farmer?.name}</p>
            </div>
          </div>
          <div className="flex items-center gap-4 rounded-lg border p-4">
             <Package className="h-8 w-8 text-primary" />
            <div>
              <p className="text-sm text-muted-foreground">Crop</p>
              <p className="font-semibold">{rootBatch.cropType}</p>
            </div>
          </div>
           <div className="flex items-center gap-4 rounded-lg border p-4">
              <Home className="h-8 w-8 text-primary" />
            <div>
              <p className="text-sm text-muted-foreground">Origin</p>
              <p className="font-semibold">{farmer?.location}</p>
            </div>
          </div>
        </div>

        <Alert>
            <ShieldCheck className="h-4 w-4" />
            <AlertTitle>Blockchain Verified</AlertTitle>
            <AlertDescription>
              Each event in this timeline is cryptographically signed and recorded on a secure, decentralized ledger for maximum transparency and trust.
            </AlertDescription>
        </Alert>
        
         {prorationFactor < 1 && finalSaleEvent && (
          <Alert className="mt-4 border-blue-500 text-blue-800">
              <AlertTitle className="text-blue-800">Showing Prorated Costs</AlertTitle>
              <AlertDescription>
                  The costs shown are proportional to the final sale of {finalSaleEvent.quantity}kg out of the total {rootBatch.originalQuantity}kg batch.
              </AlertDescription>
          </Alert>
        )}

        <Separator className="my-8" />
        
        <h3 className="text-xl font-semibold mb-6">Transaction Timeline</h3>

        <div className="space-y-8">
          {events.length > 0 ? events.map((event, index) => (
              <TimelineStep 
                key={event.id} 
                event={event}
                isLast={index === events.length - 1}
                currentUserId={currentUserId}
                prorationFactor={prorationFactor} />
            )
          ) : (
              <div className="text-center py-10 text-muted-foreground">
                  <p>No supply chain events found for this batch yet.</p>
              </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
