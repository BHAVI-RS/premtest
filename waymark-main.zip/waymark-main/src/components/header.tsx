
'use client';
import Link from 'next/link';
import React from 'react';
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from '@/components/ui/breadcrumb';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Input } from '@/components/ui/input';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import {
  Home,
  Package,
  PanelLeft,
  Search,
  PenSquare,
  GitFork,
  MessageSquare,
  Newspaper,
  Settings,
} from 'lucide-react';
import { usePathname } from 'next/navigation';
import { WaymarkIcon } from './icons';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { User } from '@/lib/types';
import { getCurrentUser } from '@/app/dashboard/settings/actions';

export function DashboardHeader({ children }: { children?: React.ReactNode }) {
  const pathname = usePathname();
  const pathSegments = pathname.split('/').filter(Boolean);
  const [user, setUser] = React.useState<User | null>(null);

  React.useEffect(() => {
    async function fetchUser() {
      // In a real app, you'd get the current user's ID from the session
      const currentUserId = pathname.includes('/dealer/') ? 'dealer-1' : 'farmer-1';
      const fetchedUser = await getCurrentUser(currentUserId);
      if(fetchedUser) {
        setUser(fetchedUser);
      }
    }
    fetchUser();
  }, [pathname]);
  
  const breadcrumbItems = pathSegments.map((segment, index) => {
    const href = '/' + pathSegments.slice(0, index + 1).join('/');
    const isLast = index === pathSegments.length - 1;
    const name = segment.replace(/-/g, ' ');

    if (isLast) {
      return (
        <BreadcrumbItem key={href}>
          <BreadcrumbPage className="capitalize">{name}</BreadcrumbPage>
        </BreadcrumbItem>
      );
    }

    return (
      <React.Fragment key={href}>
        <BreadcrumbItem>
          <BreadcrumbLink asChild>
            <Link href={href} prefetch={false} className="capitalize">
              {name}
            </Link>
          </BreadcrumbLink>
        </BreadcrumbItem>
        <BreadcrumbSeparator />
      </React.Fragment>
    );
  });


  return (
    <header className="sticky top-0 z-30 flex h-14 items-center gap-4 border-b bg-background px-4 sm:static sm:h-auto sm:border-0 sm:bg-transparent sm:px-6">
      <Sheet>
        <SheetTrigger asChild>
          <Button size="icon" variant="outline" className="sm:hidden">
            <PanelLeft className="h-5 w-5" />
            <span className="sr-only">Toggle Menu</span>
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="sm:max-w-xs">
          <nav className="grid gap-6 text-lg font-medium">
            <Link
              href="/dashboard"
              className="group flex h-10 w-10 shrink-0 items-center justify-center gap-2 rounded-full bg-primary text-lg font-semibold text-primary-foreground md:text-base"
              prefetch={false}
            >
              <WaymarkIcon className="h-5 w-5 transition-all group-hover:scale-110" />
              <span className="sr-only">WayMark</span>
            </Link>
            <Link href="/dashboard" className="flex items-center gap-4 px-2.5 text-muted-foreground hover:text-foreground" prefetch={false}>
              <Home className="h-5 w-5" />
              Dashboard
            </Link>
            <Link href="/dashboard/my-batches" className="flex items-center gap-4 px-2.5 text-muted-foreground hover:text-foreground" prefetch={false}>
              <Package className="h-5 w-5" />
              My Batches
            </Link>
            <Link href="/dashboard/price-predictor" className="flex items-center gap-4 px-2.5 text-foreground" prefetch={false}>
              <PenSquare className="h-5 w-5" />
              Sell My Crop
            </Link>
            <Link href="/dashboard/supply-chain" className="flex items-center gap-4 px-2.5 text-muted-foreground hover:text-foreground" prefetch={false}>
              <GitFork className="h-5 w-5" />
              Supply Chain
            </Link>
            <Link href="/dashboard/chats" className="flex items-center gap-4 px-2.5 text-muted-foreground hover:text-foreground" prefetch={false}>
              <MessageSquare className="h-5 w-5" />
              Chats
            </Link>
            <Link href="/dashboard/news-feed" className="flex items-center gap-4 px-2.5 text-muted-foreground hover:text-foreground" prefetch={false}>
              <Newspaper className="h-5 w-5" />
              News Feed
            </Link>
             <Link href="/dashboard/settings" className="flex items-center gap-4 px-2.5 text-muted-foreground hover:text-foreground" prefetch={false}>
              <Settings className="h-5 w-5" />
              Settings
            </Link>
          </nav>
        </SheetContent>
      </Sheet>
      <Breadcrumb className="hidden md:flex">
        <BreadcrumbList>
          {breadcrumbItems}
        </BreadcrumbList>
      </Breadcrumb>
      <div className="relative ml-auto flex-1 md:grow-0">
        <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
        <Input type="search" placeholder="Search..." className="w-full rounded-lg bg-muted pl-8 md:w-[200px] lg:w-[320px]" />
      </div>
      <div className="ml-2">
        {children}
      </div>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" size="icon" className="overflow-hidden rounded-full ml-2">
             <Avatar>
                {user?.avatarUrl && <AvatarImage src={user.avatarUrl} alt={user.name} />}
                <AvatarFallback>{user ? user.name.charAt(0) : 'U'}</AvatarFallback>
            </Avatar>
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuLabel>My Account</DropdownMenuLabel>
          <DropdownMenuSeparator />
          <DropdownMenuItem asChild>
            <Link href="/dashboard/settings">Settings</Link>
          </DropdownMenuItem>
          <DropdownMenuItem>Support</DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem asChild>
            <Link href="/">Logout</Link>
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </header>
  );
}
